function rms = trajectory_error(x, y)
  % x and y are trajectories, num_frames x num_points x 3.

  sqr_dist = sum((x - y).^2, 3);
  rms = sqrt(mean(sqr_dist, 1))';
end

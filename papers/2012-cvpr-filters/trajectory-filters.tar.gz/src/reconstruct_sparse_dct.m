% Minimizes projection error regularized by sparsity.
%
% Parameters:
% trajectory -- Vector of observations of point.
% lambda -- Weight for L1 objective term.

function [x, b] = reconstruct_sparse_dct(trajectory, lambda)
  F = trajectory.num_frames;
  basis = dctmtx(F)';

  [x, b] = reconstruct_sparse(trajectory, basis, lambda);
end

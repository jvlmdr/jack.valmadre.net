function C = LoadCameraData(filename)
fid = fopen(filename, 'r');
fscanf(fid, '%s', 1); nC = fscanf(fid, '%d', 1);
fscanf(fid, '%s', 1); nPoints = fscanf(fid, '%d', 1);
for iC = 1 : nC
    C{iC}.id = fscanf(fid, '%s', 1);
    C{iC}.t = fscanf(fid, '%f', 1);
    c = fscanf(fid, '%f', 3);
    R = fscanf(fid, '%f %f %f', [3,3])';
    K = fscanf(fid, '%f %f %f', [3,3])';
    C{iC}.P = K*R*[eye(3) -c];
    m = fscanf(fid, '%f', 2*nPoints);
    idx = find(m == -1);
    m(idx) = NaN;
    C{iC}.m = reshape(m,2,nPoints)';
end
fclose(fid);

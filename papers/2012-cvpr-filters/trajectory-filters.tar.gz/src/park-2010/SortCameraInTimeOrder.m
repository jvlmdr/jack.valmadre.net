function C1 = SortCameraInTimeOrder(C)
for iCamera = 1 : length(C)
    time(iCamera) = C{iCamera}.t;
end
[dummy, idx] = sort(time);
for iCamera = 1 : length(idx)
    C1{iCamera} = C{idx(iCamera)};
end

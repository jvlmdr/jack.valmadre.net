% Performs trajectory reconstruction for each point.
%
% Parameters:
% trajectory -- Vector of observations of point.
% filters -- Cell array of filter vectors.

function x = reconstruct_filters(trajectory, filters)
  num_frames = trajectory.num_frames;
  % Get full system of equations.
  equations = trajectory_projection_equations(trajectory);
  [Q, u] = independent_to_full(equations, num_frames);

  % Construct a convolution matrix.
  G = filter_bank_matrix(filters, num_frames, 'valid');

  x = reconstruct_linear_constrained(Q, u, G);
  x = reshape(x, [3, num_frames]);
end

function hierarchy = cmu_hierarchy()
  % Returns the joint hierarchy of the skeleton used by the CMU mocap database.

  % Bundle the joint IDs into a pseudo-enum.
  joint_ids = cmu_joints();
  num_joints = length(joint_ids);
  Joints = enum(joint_ids);

  % Connect each joint to the previous joint...
  hierarchy = (1:num_joints) - 1;
  % ...except...
  hierarchy(Joints.RIGHT_HIP) = Joints.ROOT;
  hierarchy(Joints.LOWER_BACK) = Joints.ROOT;
  hierarchy(Joints.LEFT_CLAVICLE) = Joints.THORAX;
  hierarchy(Joints.RIGHT_CLAVICLE) = Joints.THORAX;
  hierarchy(Joints.LEFT_THUMB) = Joints.LEFT_HAND;
  hierarchy(Joints.RIGHT_THUMB) = Joints.RIGHT_HAND;
end

filename = '../data/RealSceneData/CameraData_HandWave.txt';
% Prefix for saving images. Set empty to not save.
outfile = [];
%outfile = '../figures/real-scene-demo/hand-wave';

K = 8;
lambda = 1;
filters = {[-1, 2, -1] / 4};
%filters = {[-1, 2, -1] / 4, [1, -1] / 2};

views = [30, 30; 0, 0];
dct_color = [0, 0.6, 0];
filter_color = [0, 0, 0.8];
fps = 5;

% Load sequence.
scene = load_real_scene(filename);
% Find rotation that makes cameras as upright as possible.
scene.images = right_cameras(scene.images);

num_points = scene.num_points;
num_frames = scene.num_frames;
num_images = length(scene.images);

% Random colors for visualization.
colors = hsv(num_points);
colors = colors(randperm(num_points), :);

% Construct linear projection equations.
trajectories = extract_trajectories(scene);

% Find solution using DCT.
dct_soln = zeros(num_frames, num_points, 3);
for i = 1:num_points
  dct_soln(:, i, :) = reconstruct_dct(trajectories(i), K)';
end

% Construct a convolution matrix.
G = filter_bank_matrix(filters, num_frames, 'valid');
E = kron(G, eye(3));
% Construct 
filter_soln = zeros(num_frames, num_points, 3);
for i = 1:num_points
  filter_soln(:, i, :) = reconstruct_filters_regularized(trajectories(i), ...
      filters, lambda)';
end

% Plot filter reconstruction.
movie = make_scatter_movie(filter_soln, colors, {'x'});
fig = figure();
title('Filters');
display_movie(movie, fig, fps);
fprintf('Any key to continue...\n');
pause;
if ishandle(fig)
  close(fig);
end

% Plot DCT reconstruction.
movie = make_scatter_movie(dct_soln, colors, {'x'});
fig = figure();
title('Truncated DCT');
display_movie(movie, fig, fps);
fprintf('Any key to continue...\n');
pause;
if ishandle(fig)
  close(fig);
end

% Only plot a subset of points so the figures are interpretable.
subset = round(linspace(1, num_points, 20));
dct_opts = {'-', 'Color', dct_color, 'LineWidth', 2};
filter_opts = {'-', 'Color', filter_color, 'LineWidth', 2};

% Plot filter results.
figure;
plot_auto(gca(), filter_soln(:, subset, :), filter_opts{:});
axis equal;
axis vis3d;
grid on;
title('Filters');
set(gca, 'XTickLabel', {});
set(gca, 'YTickLabel', {});
set(gca, 'YTickLabel', {});

% Show from different views.
if ~isempty(outfile)
  for i = 1:size(views, 1)
    view(views(i, :));
    print([outfile, '-filters-', num2str(i)], '-depsc2');
  end
else
  view(views(1, :));
end

% Plot DCT results.
figure;
plot_auto(gca(), dct_soln(:, subset, :), dct_opts{:});
axis equal;
axis vis3d;
grid on;
title('Truncated DCT');
set(gca, 'XTickLabel', {});
set(gca, 'YTickLabel', {});
set(gca, 'YTickLabel', {});

% Show from different views.
if ~isempty(outfile)
  for i = 1:size(views, 1)
    view(views(i, :));
    print([outfile, '-dct-', num2str(i)], '-depsc2');
  end
else
  view(views(1, :));
end

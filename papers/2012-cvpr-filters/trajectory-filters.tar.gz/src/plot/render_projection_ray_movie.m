% Renders one frame of a projection ray movie.

function render_projection_ray_movie(fig, t, centers, points, colors, ...
    point_opts, line_opts)
  [num_frames, num_points, dim] = size(points);

  points = shiftdim(points, 1);
  points = points(:, :, t);
  center = centers(t, :);

  ax = gca(fig);
  cla(ax);

  % Gather the pairs of points.
  p = zeros(2, num_points, 3);
  from = ones(num_points, 1) * center;
  to = points;
  to = 1e3 * (to - from) + from;
  p(1, :, :) = from;
  p(2, :, :) = to;
  plot_auto(ax, p, line_opts{:});

  % Plot the points.
  for i = 1:num_points
    plot_auto(ax, points(i, :), point_opts{:}, 'Color', colors(i, :));
  end
end

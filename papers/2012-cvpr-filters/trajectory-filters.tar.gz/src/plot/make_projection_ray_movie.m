function movie = make_projection_ray_movie(cameras, points, colors, ...
    point_opts, line_opts)
  [num_frames, num_points, dim] = size(points);
  assert(dim == 2 || dim == 3, 'Data must be two- or three-dimensional');
  assert(length(cameras) == num_frames);

  % Compute camera centers.
  centers = zeros(num_frames, 3);
  for t = 1:num_frames
    K = extract_intrinsics(cameras(t).P);
    % Extrinsic camera matrix.
    P = inv(K) * cameras(t).P;
    R = P(:, 1:3);
    d = P(:, 4);
    centers(t, :) = (-R' * d)';
  end

  % Get axis limits.
  limits = axis_limits(reshape(points, [num_frames * num_points, dim]));

  render = @(fig, t) render_projection_ray_movie(fig, t, centers, points, ...
      colors, point_opts, line_opts);
  movie = make_movie(render, num_frames, dim, limits);
end

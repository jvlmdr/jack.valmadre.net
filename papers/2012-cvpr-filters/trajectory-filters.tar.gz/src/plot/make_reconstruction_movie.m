function movie = make_reconstruction_movie(points1, points2, opts1, opts2, ...
    line_opts)
  [num_frames, num_points, dim] = size(points1);
  assert(dim == 2 || dim == 3, 'Data must be two- or three-dimensional');

  % Check both point sets have same dimension.
  assert(length(size(points1)) == length(size(points2)));
  assert(all(size(points1) == size(points2)));

  % Get axis limits.
  points = [reshape(points1, [num_frames * num_points, dim]);
            reshape(points2, [num_frames * num_points, dim])];
  limits = axis_limits(points);

  render = @(fig, t) render_reconstruction_movie(fig, t, points1, points2, ...
      opts1, opts2, line_opts);
  movie = make_movie(render, num_frames, dim, limits);
end

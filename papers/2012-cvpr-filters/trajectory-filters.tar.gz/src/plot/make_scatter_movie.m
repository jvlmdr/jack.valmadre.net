function movie = make_scatter_movie(points, colors, opts)
  [num_frames, num_points, dim] = size(points);
  assert(dim == 2 || dim == 3, 'Data must be two- or three-dimensional');

  % Get axis limits.
  limits = axis_limits(reshape(points, [num_frames * num_points, dim]));

  render = @(fig, t) render_scatter_movie(fig, t, points, colors, opts);
  movie = make_movie(render, num_frames, dim, limits);
end

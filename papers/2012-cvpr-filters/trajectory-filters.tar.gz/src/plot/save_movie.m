function save_movie(movie, fig, image_size, dpi, output_dir, filename)
  % Set axis limits.
  if movie.num_dimensions == 2
    init2(fig, movie.limits);
  else
    init3(fig, movie.limits);
  end

  % Create empty directory for frames.
  frame_dir = [output_dir, '/', filename];
  unix(['rm -rf ', frame_dir]);
  unix(['mkdir -p ', frame_dir]);

  format = [frame_dir, '/%07d.png'];

  % Render frames.
  for t = 1:movie.num_frames
    movie.render(fig, t);
    drawnow;

    image_file = sprintf(format, t);
    print_image(fig, image_size, dpi, image_file, {'-dpng'});
  end

  % Convert to movie.
  movie_file = [output_dir, '/', filename, '.mp4'];
  unix(['ffmpeg -sameq -y -i ', format, ' ', movie_file]);

  % Remove directory of frames.
  unix(['rm -rf ', frame_dir]);
end

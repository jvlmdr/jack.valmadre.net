% Renders frame t of a point sequence.

function render_graph_movie(fig, t, edges, points, colors, point_opts, ...
    line_opts)
  [num_frames, num_points, dim] = size(points);
  num_edges = size(edges, 1);

  points = shiftdim(points, 1);
  points = points(:, :, t);

  ax = gca(fig);
  cla(ax);

  % Gather the pairs of points.
  p = zeros(2, num_edges, dim);
  p(1, :, :) = points(edges(:, 1), :);
  p(2, :, :) = points(edges(:, 2), :);
  plot_auto(ax, p, line_opts{:});

  % Plot the points.
  for i = 1:num_points
    plot_auto(ax, points(i, :), point_opts{:}, 'Color', colors(i, :));
  end
end

function movie = make_graph_movie(edges, points, colors, point_opts, line_opts)
  [num_frames, num_points, dim] = size(points);
  assert(dim == 2 || dim == 3, 'Data must be two- or three-dimensional');

  % Get axis limits.
  limits = axis_limits(reshape(points, [num_frames * num_points, dim]));

  render = @(fig, t) render_graph_movie(fig, t, edges, points, colors, ...
      point_opts, line_opts);
  movie = make_movie(render, num_frames, dim, limits);
end

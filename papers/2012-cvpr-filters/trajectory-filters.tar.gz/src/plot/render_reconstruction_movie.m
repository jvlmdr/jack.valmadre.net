function render_reconstruction_movie(fig, t, points1, points2, opts1, opts2, ...
    line_opts)
  [num_frames, num_points, dim] = size(points1);

  % Extract this frame only.
  points1 = shiftdim(points1, 1);
  points1 = points1(:, :, t);
  points2 = shiftdim(points2, 1);
  points2 = points2(:, :, t);

  ax = gca(fig);
  cla(ax);

  % Gather the pairs of points.
  p = zeros(2, num_points, dim);
  p(1, :, :) = points1;
  p(2, :, :) = points2;
  plot_auto(ax, p, line_opts{:});

  % Plot the points.
  plot_auto(ax, points1, opts1{:});
  plot_auto(ax, points2, opts2{:});
end

function display_movie(movie, fig, fps)
  % Set axis limits.
  if movie.num_dimensions == 2
    init2(fig, movie.limits);
  else
    init3(fig, movie.limits);
  end

  animation = Animation(fig);
  animation.render = movie.render;
  animation.length = movie.num_frames;
  animation.fps = fps;

  animation.play();
end

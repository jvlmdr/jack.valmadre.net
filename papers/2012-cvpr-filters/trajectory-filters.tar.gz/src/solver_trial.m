function result = solver_trial(scene, solvers, solver_names)
  num_solvers = length(solvers);
  num_frames = scene.num_frames;
  num_points = scene.num_points;

  % Run each solver.
  reconstructions = zeros(num_frames, num_points, 3, num_solvers);
  for i = 1:length(solvers)
    disp(['  Solver: ', solver_names{i}]);
    reconstructions(:, :, :, i) = reconstruct_all_points(scene, solvers{i});
  end

  % Return the full reconstruction for every solver.
  result = struct('reconstructions', reconstructions);
end

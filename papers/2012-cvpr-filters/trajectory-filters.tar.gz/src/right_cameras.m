% Re-orients a set of perspective cameras to be collectively upright.

function images = right_cameras(images)
  num_images = length(images);

  % Make a second pass and extract 'up' vector of each camera.
  up = zeros(num_images, 3);
  for i = 1:num_images
    % Extract intrinsics.
    [intrinsics, R] = extract_intrinsics(images(i).camera.P);
    up(i, :) = R(2, :);
  end

  % Find rotation that makes cameras as upright as possible.
  R = procrustes(up, ones(num_images, 1) * [0, 1, 0]);
  if det(R) < 0
    % Free to swap x and z since they are both zero in the template [0, 1, 0].
    R = flipud(R);
  end

  % Build homogeneous 3D transform.
  % Not sure if R should be transposed below or not...
  H = [R', zeros(3, 1); zeros(1, 3), 1];

  % Apply to all cameras.
  for i = 1:num_images
    % Extract intrinsics.
    P = images(i).camera.P;
    P = P * H;
    images(i).camera.P = P;
  end
end

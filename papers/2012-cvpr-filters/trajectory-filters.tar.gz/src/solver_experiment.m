setup;

if ~exist('solver-experiment-summary.mat', 'file')
  if ~exist('solver-experiment-results.mat', 'file')
    if ~exist('../data/mocap-data.mat', 'file')
      data = mocap_data();
      save('../data/mocap-data', '-struct', 'data');
    else
      data = load('../data/mocap-data');
    end

    experiment = solver_experiment_run(data);
    save('solver-experiment-results', '-struct', 'experiment');
  else
    experiment = load('solver-experiment-results');
  end

  summary = solver_experiment_summarize(experiment);
  save('solver-experiment-summary', '-struct', 'summary');
else
  summary = load('solver-experiment-summary');
end

solver_experiment_visualize(summary, '../figures/solver-experiment/');

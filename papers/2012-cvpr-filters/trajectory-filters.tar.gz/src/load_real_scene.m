function scene = load_real_scene(filename)
  % Use Park et al's LoadCameraData() function.
  C = LoadCameraData(filename);
  % Probably not necessary, but may as well...
  C = SortCameraInTimeOrder(C);

  % Number of frames.
  num_images = length(C);
  % Number of points. m contains NaNs if points were not observed.
  num_points = size(C{1}.m, 1);

  % Read into our structure.
  for i = 1:num_images
    assert(size(C{i}.m, 1) == num_points);

    times(i) = C{i}.t;
    points_i = C{i}.m;
    indices{i} = find(~any(isnan(points_i(:, 1)), 2));
    points_i = points_i(indices{i}, :);
    P = C{i}.P;

    points{i} = points_i;
    cameras{i} = struct('P', P);
  end

  % Ensure times start at 1.
  times = times - min(times) + 1;
  num_frames = max(times);

  times = mat2cell(times, 1, ones(num_images, 1));
  images = struct('camera', cameras, 'time', times, 'indices', indices, ...
      'points', points);

  scene = struct('images', images, 'num_frames', num_frames, ...
      'num_points', num_points);
end

% Groups projections from a scene by point.
%
% Parameters:
% scene -- Struct with:
%   num_frames
%   num_points
%   images -- Vector of structs with:
%     time -- Frame index of image.
%     camera -- Camera struct.
%     indices -- num_points(i) vector of indices.
%     points -- num_points(i) x 2 matrix.
%
% Returns:
% trajectories -- Vector of structs with
%   num_frames -- Number of frames in sequence
%   images -- Vector of structs with:
%     time
%     camera
%     point

function trajectories = extract_trajectories(scene)
  % Number of projection frames.
  num_images = length(scene.images);
  num_points = scene.num_points;
  num_frames = scene.num_frames;

  trajectory_images = cell(1, num_points);

  % Initialize structure.
  for i = 1:num_points
    trajectory_images{i} = struct('time', {}, 'camera', {}, 'point', {});
  end

  % Copy into new structure.
  for i = 1:num_images
    img = scene.images(i);
    num_observed = size(img.points, 1);

    for j = 1:num_observed
      w = img.points(j, :)';
      index = img.indices(j);

      % Append.
      traj_img = struct('time', img.time, 'camera', img.camera, 'point', w);
      trajectory_images{index} = [trajectory_images{index}, traj_img];
    end
  end

  trajectories = struct('num_frames', num_frames, 'images', trajectory_images);
end

% Reconstructs trajectory with automatic basis size selection.
%
% Parameters:
% trajectory -- Vector of observations of point.
% basis -- F x F basis.
% max_gain -- Threshold on reconstructability.
%
% Returns:
% F x 3 matrix of average distance from true position.

function x = reconstruct_basis_auto(trajectory, basis, max_gain)
  F = trajectory.num_frames;

  equations = trajectory_projection_equations(trajectory);

  % Get full system of equations.
  % Need Q_null to choose basis size.
  [Q, u] = independent_to_full(equations, F);
  Q_null = trajectory_nullspace(equations);

  % Estimate the best basis size.
  K = choose_basis_size(Q_null, basis, max_gain);

  % Reconstruct using the basis size found.
  x = reconstruct_basis(equations, basis(:, 1:K));
end

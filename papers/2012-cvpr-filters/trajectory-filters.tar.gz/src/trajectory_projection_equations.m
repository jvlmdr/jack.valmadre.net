% Converts observations of a single point into a set of linear equations.
%
% Parameters:
% trajectory -- Struct with:
%   num_frames -- Number of frames in sequence.
%   images -- Vector of structs with:
%     time
%     camera
%     point
%
% Returns:
% equations -- Vector of structs with:
%   t -- Frame of observation.
%   Q, q -- 2x3 system defining projection constraint Qx = q.

function equations = trajectory_projection_equations(trajectory)
  % Number of projection frames.
  num_images = length(trajectory.images);

  t = cell(1, num_images);
  Q = cell(1, num_images);
  q = cell(1, num_images);

  for i = 1:num_images
    img = trajectory.images(i);
    t{i} = img.time;
    [Q{i}, q{i}] = projection_equation(img.camera.P, img.point);
  end

  equations = struct('t', t, 'Q', Q, 'q', q);
end

function [structure, cameras, projections] = person_sequence(mocap_file, dtheta)
  % Film from 5m away with a 50mm focal length.
  RADIUS = 5e3;
  FOCAL_LENGTH = 50;

  % Load motion capture sequence.
  structure = load_mocap(mocap_file);

  num_frames = size(structure, 1);
  num_points = size(structure, 2);

  % Generate cameras along circle.
  theta = (0:num_frames - 1) * dtheta;
  % Generate cameras along circle.
  cameras = generate_cameras_on_circle(FOCAL_LENGTH, theta, RADIUS, ...
      [0; 1000; 0]);

  % Project points into cameras.
  projections = project_points(cameras, structure);
end

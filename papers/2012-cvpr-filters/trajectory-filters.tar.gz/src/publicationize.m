function publicationize()

set(gca, 'Box', 'off');
set(gca, 'TickDir', 'out');
grid('on');

set(gcf, 'PaperUnits', 'centimeters');
set(gcf, 'PaperSize', [12, 9]);
set(gcf, 'PaperPosition', [0, 0, 12, 9]);
set(gca, 'FontSize', 10);

end

% Performs general linear reconstruction.
%
% Finds x which minimizes
%   1/2 x' M x + 1/2 lambda || Q x - u ||^2
% where M = V^T V, V = kron(E, eye(3)).

function x = reconstruct_linear_regularized(Q, u, E, lambda)
  m = size(E, 1);

  % Set up quadratic objective.
  V = kron(E, eye(3));

  A = [V; sqrt(lambda) * Q];
  b = [zeros(3 * m, 1); sqrt(lambda) * u];
  x = A \ b;
end

function solver_experiment_visualize(summary, outfile)
  if nargin < 2
    outfile = [];
  end

  alpha = 0.5;
  markers = 'osd^vx+<>*';

  DEVICE = '-dpdf';
  LINE_WIDTH = 1.5;

  solver_names = summary.solver_names;
  colors = summary.solver_colors;
  subsets = summary.solver_subsets;
  subset_names = summary.solver_subset_names;
  err = summary.error;

  omegas_deg = round(summary.omegas * 180 / pi);
  lims = [min(omegas_deg), max(omegas_deg), min(err(:)), max(err(:))];

  % Plot each subset in full.
  for i = 1:length(subsets)
    figure;
    hold all;
    publicationize();
    set(gca, 'ColorOrder', colors(subsets{i}, :));
    set(gca, 'XScale', 'log', 'YScale', 'log');
    for j = 1:length(subsets{i})
      plot(omegas_deg, err(:, subsets{i}(j)), 'Marker', markers(j), ...
        'LineWidth', LINE_WIDTH);
    end
    axis(lims);
    set(gca, 'XTick', omegas_deg);
    ylabel('Average RMS 3D error (mm)');
    xlabel('Camera speed (deg/frame)');

    % Print without legend first, otherwise it just gets in the way!
    if ~isempty(outfile)
      print([outfile, subset_names{i}], DEVICE);
    end
    % Now display legend.
    legend(solver_names(subsets{i}), 'Location', 'EastOutside');
    axis off;
    if ~isempty(outfile)
      print([outfile, subset_names{i}, '-legend'], DEVICE);
    end
  end

  % Fade out background colors a bit.
  bg_colors = colors(subsets{1}, :);
  bg_colors = 1 - alpha * (1 - bg_colors);

  % Compare each subset to the first one.
  for i = 2:length(subsets)
    figure;
    hold all;
    publicationize();

    % Draw first subset in background.
    set(gca, 'ColorOrder', bg_colors);
    plot(omegas_deg, err(:, subsets{1}), 'LineWidth', LINE_WIDTH);

    % Plot lines with different markers.
    set(gca, 'ColorOrder', colors(subsets{i}, :));
    h = zeros(1, length(subsets{i}));
    for j = 1:length(subsets{i})
      h(j) = plot(omegas_deg, err(:, subsets{i}(j)), 'Marker', markers(j), ...
        'LineWidth', LINE_WIDTH);
    end

    set(gca, 'XScale', 'log', 'YScale', 'log');
    axis(lims);
    set(gca, 'XTick', omegas_deg);
    ylabel('Average RMS 3D error (mm)');
    xlabel('Camera speed (deg/frame)');

    % Print without legend first, otherwise it just gets in the way!
    if ~isempty(outfile)
      filename = [outfile, subset_names{1}, '-', subset_names{i}];
      print(filename, DEVICE);
    end

    % Now display legend.
    legend(h, solver_names(subsets{i}), 'Location', 'EastOutside');
    axis off;
    if ~isempty(outfile)
      print([filename, '-legend'], DEVICE);
    end
  end

  return;

  % Best of each subset except the first.
  best_of_subset = [4, 1, 3];
  best_subset = zeros(1, length(subsets) - 1);
  for i = 2:length(subsets)
    best_subset(i - 1) = subsets{i}(best_of_subset(i - 1));
  end

  % Compare each subset to the first one.
  figure;
  hold all;
  publicationize();

  % Draw first subset in background.
  set(gca, 'ColorOrder', bg_colors);
  plot(omegas_deg, err(:, subsets{1}), 'LineWidth', 2);

  % Plot lines with different markers.
  set(gca, 'ColorOrder', colors(best_subset, :));
  h = zeros(1, length(best_subset));
  for j = 1:length(best_subset)
    h(j) = plot(omegas_deg, err(:, best_subset(j)), 'Marker', markers(j), ...
      'LineWidth', LINE_WIDTH);
  end

  set(gca, 'XScale', 'log', 'YScale', 'log');
  axis(lims);
  set(gca, 'XTick', omegas_deg);
  ylabel('Average RMS 3D error (mm)');
  xlabel('Camera speed (deg/frame)');

  % Print without legend first, otherwise it just gets in the way!
  if ~isempty(outfile)
    filename = [outfile, 'best'];
    print(filename, DEVICE);
  end

  % Now display legend.
  legend(h, solver_names(best_subset), 'Location', 'EastOutside');
  axis off;
  if ~isempty(outfile)
    print([filename, '-legend'], DEVICE);
  end
end

function [u, g, e] = irreconstructability(Q_null, E, x)
  % Returns the gain term in reconstructability.

  V = kron(E, eye(3));
  M = V' * V;

  A = Q_null' * M * Q_null;
  g = cond(A);

  e = norm(Q_null' * M * x) / norm(A);

  u = g * e;
end

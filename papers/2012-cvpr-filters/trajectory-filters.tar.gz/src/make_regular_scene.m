% Constructs a scene from cameras and projections.
% Assumes no missing data, exactly one camera per frame (hence "regular").
%
% Parameters:
% cameras -- Vector of camera structs. length(cameras) == num_frames
% projections -- Matrix of 2D projections.
%   size(cameras) == [num_frames, num_points, 3]

function scene = make_regular_scene(cameras, projections)
  num_frames = size(projections, 1);
  num_points = size(projections, 2);

  % Put cameras and points into struct.
  cameras = mat2cell(cameras(:)', 1, ones(num_frames, 1));
  times = mat2cell(1:num_frames, 1, ones(num_frames, 1));
  projections = shiftdim(projections, 1);
  projections = mat2cell(projections, num_points, 2, ones(num_frames, 1));
  % Every point visible in every frame.
  indices = 1:num_points;

  images = struct('camera', cameras, 'time', times, 'indices', indices, ...
      'points', projections(:)');
  scene = struct('images', images, 'num_frames', num_frames, ...
      'num_points', num_points);
end

% Performs general linear reconstruction.
%
% Finds x which minimizes ||x||_M such that Qx == u,
% where M = V^T V, V = kron(E, eye(3)).

function x = reconstruct_linear_constrained(Q, u, E)
  m = size(Q, 1);
  n = size(Q, 2);

  % Set up quadratic objective.
  V = kron(E, eye(3));
  M = V' * V;

  % Solve using Lagrange multipliers.
  A = [M, Q'; Q, zeros(m)];
  b = [zeros(n, 1); u];
  x = A \ b;

  x = x(1:n);
end

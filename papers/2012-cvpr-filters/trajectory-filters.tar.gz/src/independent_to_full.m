% Constructs full system from individual systems with timestamps.
%
% Parameters:
% equations -- Vector of equations from each image.
% num_frames -- Number of frames in the trajectory.
%
% Returns:
% Full system Qx = u, Q is 2M x 3F, u is 2M x 1.
% If there is one observation per frame, M = F.

function [Q, u] = independent_to_full(equations, num_frames)
  % Matrices to construct.
  Q = sparse(0, 3 * num_frames);
  u = zeros(0, 1);

  num_images = length(equations);

  for i = 1:num_images
    equation = equations(i);

    % Add the projection matrix to the overall matrix.
    t = equation.t;
    e = sparse(num_frames, 1);
    e(t) = 1;
    Q = [Q; kron(e', equation.Q)];
    u = [u; equation.q];
  end
end

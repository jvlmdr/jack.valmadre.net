function summary = solver_experiment_summarize(experiment)
  results = experiment.results;
  data = experiment.data;

  num_solvers = length(experiment.solver_names);
  [num_sequences, num_omegas] = size(data.scenes);
  [num_frames, num_points, three] = size(data.points);

  % Unpack results and calculate error.
  err = zeros(num_sequences, num_omegas, num_solvers, num_points);
  for i = 1:num_sequences
    for j = 1:num_omegas
      for k = 1:num_solvers
        estimate = results(i, j).reconstructions(:, :, :, k);
        err(i, j, k, :) = trajectory_error(data.points(:, :, :, i), estimate);
      end
    end
  end
  % Average error over all points.
  err = mean(err, 4);          
  err = shiftdim(mean(err, 1));

  summary = struct('error', err, ...
    'solver_names', {experiment.solver_names}, ...
    'solver_colors', {experiment.solver_colors}, ...
    'solver_subsets', {experiment.solver_subsets}, ...
    'solver_subset_names', {experiment.solver_subset_names}, ...
    'omegas', experiment.data.omegas);
end

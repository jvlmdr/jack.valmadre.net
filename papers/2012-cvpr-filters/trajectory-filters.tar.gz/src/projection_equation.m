function [Q, q] = projection_equation(P, w)
  % Gives the projection equation for a single point in a calibrated viewpoint.
  %
  % Parameters:
  % P -- 4 x 3 projection matrix.
  % w -- 2 x 1 projected point.
  %
  % Returns:
  % Q and q such that Q * x = q defines the projection equation.

  % cross([w; 1], P * [x; 1]) = 0
  % W * P * [x; 1] = 0, with W = cross_matrix([w; 1])
  % (W * P) * [x; 0] = -(W * P) * [0; 1]

  A = P(1:2, 1:3);
  b = P(1:2, 4);
  c = P(3, 1:3)';
  d = P(3, 4);

  Q = (A - w * c');
  q = d * w - b;
end

% Enforces DCT basis of size K and minimizes projection error.
%
% Parameters:
% trajectory -- Vector of observations of point.
% K -- Size of DCT basis.
%
% Returns:
% F x 3 matrix of average distance from true position.

function x = reconstruct_dct(trajectory, K)
  F = trajectory.num_frames;
  equations = trajectory_projection_equations(trajectory);

  phi = dctmtx(F)';
  phi = phi(:, 1:K);
  x = reconstruct_basis(equations, phi);
end

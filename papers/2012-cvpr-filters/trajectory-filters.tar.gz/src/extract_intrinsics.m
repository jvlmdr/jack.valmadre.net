function [K, R] = extract_intrinsics(P)
  % Permutation matrix. A A = I, A = A'.
  A = fliplr(eye(3));

  % M = K R
  M = P(:, 1:3);

  % M' = Q U
  [Q, U] = qr(M' * A);

  % M' = Q L
  Q = Q * A;
  L = A * U * A;

  % M = U Q
  Q = Q';
  U = L';

  % M = K R
  K = U;
  R = Q;

  % If the focal lengths have a different sign, then negate one.
  fx = K(1, 1);
  fy = K(2, 2);
  if fx * fy < 0
    K = K * diag([1, -1, 1]);
    R = diag([1, -1, 1]) * R;
  end

  % Determinant should be +1.
  if det(R) < 0
    K = -K;
    R = -R;
  end

  % There still remains an ambiguity of diag([-1, -1, 1]) between K and R.
  % Ensure that both focal lengths are negative.
  fx = K(1, 1);
  fy = K(2, 2);
  assert(fx * fy > 0);
  if fx > 0
    K = K * diag([-1, -1, 1]);
    R = diag([-1, -1, 1]) * R;
  end
end

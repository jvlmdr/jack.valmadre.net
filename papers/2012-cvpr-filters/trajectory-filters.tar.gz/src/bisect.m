function [x, f_x] = bisect(f, a, b)
  % Finds the largest value f(x) that is less than zero.
  % Assumes f(x) is monotonic between a and b.

  f_a = f(a);
  f_b = f(b);
  finished = false;
  x = nan;
  f_x = nan;

  while ~finished
    if f_a * f_b > 0
      % Same sign -- return largest negative or smallest positive number.
      if (f_a < 0 && f_a > f_b) || (f_a > 0 && f_a < f_b)
        x = a;
      else
        x = b;
      end
      finished = true;
    else
      % f(a) and f(b) are opposite sign.
      if (b - a) <= 1
        % Tolerance limit. Return the negative number.
        if a < b
          x = a;
        else
          x = b;
        end
        finished = true;
      else
        c = floor((a + b) / 2);
        f_c = f(c);

        if f_b * f_c > 0
          % f(b) and f(c) are same sign.
          b = c;
          f_b = f_c;
        else
          a = c;
          f_a = f_c;
        end
      end
    end
  end

  if x == a
    f_x = f_a;
  elseif x == b
    f_x = f_b;
  end
end

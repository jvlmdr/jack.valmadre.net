function E = filter_bank_matrix(filters, n, shape)
  % Constructs an energy-responds matrix for a bank of filters.

  E = sparse(0, n);

  for i = 1:length(filters)
    h = filters{i};
    H = conv_matrix(h, n, shape);
    E = [E; H];
  end
end

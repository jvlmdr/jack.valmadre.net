function data = mocap_data()
  if nargin < 1
    outfile = [];
  end

  % Directory to load mocap data from.
  mocap_dir = '/staticdata/cmu-mocap/';
  % Standard camera focal length, 50mm.
  f = 50;
  % Fly around the subject at a radius of double its spherical bounds.
  relative_radius = 2;
  % Number of frames in each sequence.
  num_frames = 100;
  % Rate to sample motion capture data at. Original sample rate is 120fps.
  downsample = 4;
  % How many random sequences to load.
  num_sequences = 100;
  % Fly around rate in degrees per frame.
  omegas_deg = [1, 2, 5, 10, 20, 45, 90];
  omegas = omegas_deg * pi / 180;
  num_omegas = length(omegas);

  % Random seed for motion capture sequences.
  rand_seed = 42;

  % Get a sequence of random mocap scenes.
  [points, sequence_files, offsets] = random_mocap_sequences(mocap_dir, ...
    'all-point-paths', num_frames, num_sequences, downsample, rand_seed);
  % Number of points.
  num_points = size(points, 2);

  % Center trajectories about origin and find bounds.
  [points, max_radius] = center_trajectories(points);
  radius = max_radius * relative_radius;

  cameras = cell([num_sequences, num_omegas]);
  projections = cell([num_sequences, num_omegas]);

  % Cell array of 1..num_frames.
  times = mat2cell(1:num_frames, 1, ones(num_frames, 1));
  indices = 1:num_points;

  images = cell(num_sequences, num_omegas);

  for i = 1:num_sequences
    % Print progress.
    if mod(i, 10) == 0
      fprintf('Projecting sequence %d\n', i);
    end

    for j = 1:num_omegas
      % Position of cameras around circle.
      angles = (0:num_frames - 1) * omegas(j);
      % Generate cameras on circle, looking at origin.
      cameras = generate_cameras_on_circle(f, angles, radius(i));
      % Project points into cameras.
      projections = project_points(cameras, points(:, :, :, i));

      % Convert to cells.
      cameras = arrayfun(@(x) x, cameras, 'UniformOutput', false);
      projections = shiftdim(projections, 1);
      projections = mat2cell(projections, num_points, 2, ones(num_frames, 1));

      images{i, j} = struct('time', times(:), 'camera', cameras(:), ...
          'indices', indices, 'points', projections(:));
    end
  end

  scenes = struct('images', images, 'num_frames', num_frames, ...
      'num_points', num_points);

  % Group mocap information together.
  mocap = struct('files', {sequence_files}, 'offsets', offsets, ...
    'downsample', downsample);

  % Full data structure.
  data = struct('scenes', scenes, 'points', points, 'omegas', omegas, ...
    'mocap', mocap);
end

function [points, max_radius] = center_trajectories(points)
  % Get dimensions.
  [num_frames, num_points, three, num_sequences] = size(points);

  % Flatten over all points and frames.
  x = reshape(points, [num_frames * num_points, 3, num_sequences]);

  % Center bounding box about origin.
  centroids = (max(x) + min(x)) / 2;
  centroids = repmat(centroids, [num_frames * num_points, 1, 1]);
  x = x - centroids;

  % Get maximum distance from the origin.
  radius = sum(x .^ 2, 2);
  max_radius = sqrt(max(radius));
  max_radius = reshape(max_radius, [num_sequences, 1]);

  % Reshape to return.
  points = reshape(x, [num_frames, num_points, 3, num_sequences]);
end

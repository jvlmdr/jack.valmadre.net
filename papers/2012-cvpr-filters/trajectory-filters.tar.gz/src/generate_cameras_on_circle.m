function cameras = generate_cameras_on_circle(f, theta, r, c, t)
  % theta -- Vector of angles on the circle.
  % f -- Camera focal length.
  % r -- Radius of circle.
  % c -- Center of circle. Optional, default is origin.
  % t -- Target (point to look at). Optional, default is origin.
  
  if nargin < 4
    c = zeros(3, 1);
  end
  if nargin < 5
    t = zeros(3, 1);
  end

  F = length(theta);
  projection = cell(F, 1);
  center = cell(F, 1);
  transform = cell(F, 1);

  % Ensure column vectors.
  c = c(:);
  t = t(:);

  for n = 1:F
    % Camera position.
    x = -roty(theta(n))' * [0; 0; r] + c;

    % "Look" vector from camera center to target.
    look = t - x;
    k = look / norm(look);
    j = [0; 1; 0];
    % Assume k is on xz plane, so that cross product can't fail.
    i = cross(j, k);
    % Construct rotation matrix.
    R = [i, j, k]';

    % Displacement of scene relative to camera *after* rotation.
    d = -R * x;

    % Compose rotation and translation.
    H = [R, d; 0, 0, 0, 1];
    % Incorporate projection transform.
    P = perspective_projection(f);
    P = P * H;

    projection{n} = P;
    transform{n} = H;
    center{n} = x;
  end

  cameras = struct('P', projection, 'transform', transform, 'center', center);
end

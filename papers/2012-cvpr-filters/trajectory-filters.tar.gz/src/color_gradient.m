function c = color_gradient(a, b, n)
  % Creates a gradient of length n from a to b.

  theta = (0:1:n-1)' / (n - 1);
  c = theta * b + (1 - theta) * a;
end

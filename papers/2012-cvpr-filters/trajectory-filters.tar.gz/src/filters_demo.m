% File to load mocap data from.
mocap_file = '../data/cmu-mocap/09_09.mat';
% Radians of orbit to move per frame.
omega = 10 / 180 * pi;
% Interactive (show movies) or non-interactive (save movies).
interactive = true;

% For saving movies only:
movie_dir = '../figures/filters-demo';
image_size = [1280, 720];
dpi = 150;
% For displaying movies only:
fps = 15;

edge_color = [0.5, 0.5, 0.5];
ray_color = [0.5, 0.5, 0.5];
error_color = [0.5, 0.5, 0.5];

% Different solvers to use in experiment.
solvers = [...
  struct(...
    'solve', @(x) reconstruct_filters(x, {[-1, 1]}), ...
    'name', '(-1, 1)', ...
    'id', 'filter-first-diff'), ...
  struct(...
    'solve', @(x) reconstruct_filters(x, {[-1, 2, -1]}), ...
    'name', '(-1, 2, -1)', ...
    'id', 'filter-second-diff'), ...
  struct(...
    'solve', @(x) reconstruct_dct(x, 4), ...
    'name', 'K = 4', ...
    'id', 'dct-too-small'), ...
  struct(...
    'solve', @(x) reconstruct_dct(x, 9), ...
    'name', 'K = 9', ...
    'id', 'dct-goldilocks'), ...
  struct(...
    'solve', @(x) reconstruct_dct(x, 11), ...
    'name', 'K = 11', ...
    'id', 'dct-too-large'), ...
];
num_solvers = length(solvers);

% Load sequence, generate cameras and project.
[points, cameras, projections] = person_sequence(mocap_file, omega);
scene = make_regular_scene(cameras, projections);
num_frames = scene.num_frames;
num_points = scene.num_points;

% Get edges (for visualization only).
edges = hierarchy_to_edges(cmu_hierarchy());
% Generate colors for visualization.
colors = hsv(num_points);
colors = colors(randperm(num_points), :);

% Extract observations of trajectory of each point.
trajectories = extract_trajectories(scene);

% Visualize ground truth.
movie = make_graph_movie(edges, points, colors, {'o', 'LineWidth', 2}, ...
    {'-', 'Color', edge_color});
if interactive
  fig = figure();
  title(gca(fig), 'Ground truth 3D structure');
  display_movie(movie, fig, fps);

  fprintf('Any key to continue...\n');
  pause;
  if ishandle(fig)
    close(fig);
  end
else
  fig = figure();
  save_movie(movie, fig, image_size, dpi, movie_dir, 'ground-truth');
  close(fig);
end

% Visualize projections.
movie = make_graph_movie(edges, projections, colors, {'o', 'LineWidth', 2}, ...
    {'-', 'Color', edge_color});
if interactive
  fig = figure();
  title(gca(fig), 'Projections');
  display_movie(movie, fig, fps);

  fprintf('Any key to continue...\n');
  pause;
  if ishandle(fig)
    close(fig);
  end
else
  fig = figure();
  save_movie(movie, fig, image_size, dpi, movie_dir, 'projections');
  close(fig);
end

% Visualize back-projected rays.
movie = make_projection_ray_movie(cameras, points, colors, ...
    {'o', 'LineWidth', 2}, {'-', 'Color', edge_color});
if interactive
  fig = figure();
  title(gca(fig), 'Back-projected rays');
  display_movie(movie, fig, fps);

  fprintf('Any key to continue...\n');
  pause;
  if ishandle(fig)
    close(fig);
  end
else
  fig = figure();
  save_movie(movie, fig,image_size, dpi, movie_dir, 'rays');
  close(fig);
end

% Solve the reconstruction using each method.
solutions = zeros(num_frames, num_points, 3, num_solvers);
for i = 1:num_solvers
  fprintf('Reconstructing using "%s"...\n', solvers(i).name);

  for j = 1:num_points
    % Perform reconstruction.
    solutions(:, j, :, i) = solvers(i).solve(trajectories(j))';
  end
end

% Calculate error in 3D space.
err = zeros(num_solvers, 1);
for i = 1:num_solvers
  diff = solutions(:, :, :, i) - points;
  diff = reshape(diff, [num_frames * num_points, 3]);
  err(i) = mean(sqrt(sum(diff .^ 2, 2)));
end

if interactive
  % Plot reconstruction error of each method.
  fig = figure();
  bar(gca(fig), err);
  set(gca(fig), 'XTickLabel', {solvers.name});
  ylabel(gca(fig), 'Average 3D point error');

  fprintf('Any key to continue...\n');
  pause;
  if ishandle(fig)
    close(fig);
  end
end

% Plot results.
for i = 1:num_solvers
  movie = make_reconstruction_movie(points, solutions(:, :, :, i), ...
      {'ko', 'LineWidth', 1}, {'rx', 'LineWidth', 2}, ...
      {'-', 'Color', error_color});

  if interactive
    fig = figure();
    title(gca(fig), sprintf('Reconstruction using "%s"', solvers(i).name));
    display_movie(movie, fig, fps);
    fprintf('Any key to continue...\n');
    pause;
    if ishandle(fig)
      close(fig);
    end
  else
    name = ['solution-', solvers(i).id];
    fig = figure();
    save_movie(movie, fig, image_size, dpi, movie_dir, name);
    close(fig);
  end
end

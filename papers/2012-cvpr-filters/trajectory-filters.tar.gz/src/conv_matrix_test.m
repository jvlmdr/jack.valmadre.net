function conv_matrix_test()
  test_full();
  test_valid();
  test_circular();
  fprintf('All tests passed!\n');
end

function test_full()
  test_conv('full', @(x, h) conv(x, h, 'full'));
end

function test_valid()
  test_conv('valid', @(x, h) conv(x, h, 'valid'));
end

function test_circular()
  test_conv('circ', @circ_conv);
end

function test_conv(shape, f)
  m = 10;
  n = 100;
  h = rand(m, 1);
  x = rand(n, 1);
  H = conv_matrix(h, n, shape);
  y = f(x, h);
  z = H * x;
  assert(roughly_equal(y, z), ['shape = ''', shape, ''' is inaccurate']);
end

function c = roughly_equal(x, y)
  x = x(:);
  y = y(:);
  if length(x) ~= length(y)
    error('x and y are not same length');
  else
    c = (norm(x - y) / sqrt(norm(x) * norm(y))) < 1e-6;
  end
end

function y = circ_conv(x, h)
  x = x(:);
  h = h(:);
  nx = length(x);
  nh = length(h);
  n = max(nx, nh);
  x = [x; zeros(n - nx, 1)];
  h = [h; zeros(n - nh, 1)];
  y = ifft(fft(x) .* fft(h));
end

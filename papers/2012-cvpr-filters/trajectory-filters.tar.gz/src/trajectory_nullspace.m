% Finds the nullspace of all cameras for a trajectory.

function Q_null = trajectory_nullspace(equations)
  % Assume that there is exactly one equation per frame.
  F = length(equations);

  Q_null = sparse(3 * F, F);

  for t = 1:F
    equation = equations(t);

    Q = equation.Q;
    v = cross(Q(1, :)', Q(2, :)');
    v = v / norm(v);

    Q_null(3 * (t - 1) + (1:3), t) = v;
  end
end

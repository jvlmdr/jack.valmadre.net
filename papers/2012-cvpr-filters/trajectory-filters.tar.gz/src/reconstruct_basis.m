% Enforces basis and minimizes projection error.
%
% Parameters:
% equations -- Vector of constraints on trajectory.
% phi -- F x K basis.

function x = reconstruct_basis(equations, phi)
  F = size(phi, 1);

  % Get full system of equations.
  [Q, u] = independent_to_full(equations, F);
  % Construct 3D basis.
  phi3 = kron(phi, eye(3));
  % Perform reconstruction.
  x = phi3 * ((Q * phi3) \ u);

  x = reshape(x, [3, F]);
end

% Runs a reconstruction algorithm for all points in a sequence.
%
% Parameters:
% scene -- Struct with:
%   num_frames
%   num_points
%   images -- Vector of structs with:
%     time -- Frame index of image.
%     camera -- Camera struct.
%     indices -- num_points(i) vector of indices.
%     points -- num_points(i) x 2 matrix.
% reconstruct -- Maps a function f(trajectory) -> x (3F x 1 vector)
%
% Returns:
% F x N x 3 matrix.

function reconstruction = reconstruct_all_points(scene, reconstruct)
  num_points = scene.num_points;
  num_frames = scene.num_frames;

  trajectories = extract_trajectories(scene);

  reconstruction = zeros(num_frames, num_points, 3);

  for i = 1:num_points
    % Perform reconstruction.
    X = reconstruct(trajectories(i));

    % Reshape and pack into results.
    reconstruction(:, i, :) = X';
  end
end

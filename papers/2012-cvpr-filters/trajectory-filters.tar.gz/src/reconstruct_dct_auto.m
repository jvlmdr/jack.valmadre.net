% Enforces DCT basis with automatic size and minimizes projection error.
%
% Parameters:
% trajectory -- Vector of observations of point.
% max_gain -- Threshold on gain term of irreconstructability for choosing K.
%
% Returns:
% F x 3 matrix of average distance from true position.

function x = reconstruct_dct_auto(trajectory, max_gain)
  F = trajectory.num_frames;
  x = reconstruct_basis_auto(trajectory, dctmtx(F)', max_gain);
end

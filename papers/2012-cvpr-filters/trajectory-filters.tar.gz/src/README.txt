Author: Jack Valmadre (jack.valmadre@gmail.com)
Date: 13 Feb 2013

Code to accompany CVPR 2012 paper "General trajectory prior for non-rigid
reconstruction."

Scripts:
- solver_experiment.m
- real_scene_demo.m
- filters_demo.m

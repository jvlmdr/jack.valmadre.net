% Automatically selects basis size given full basis and camera nullspace.
%
% Parameters:
% Q_null -- 3F x F matrix of camera nullspace.
% basis -- F x F orthonormal matrix. 
% max_gain -- Limit on gain term to seek.

function K = choose_basis_size(Q_null, basis, max_gain)
  F = size(basis, 1);

  % Find highest condition number below threshold using bisection.
  f = @(K) irreconstructability_gain(Q_null, basis(:, K + 1:end)') - max_gain;
  K = bisect(f, 1, floor(2 * F / 3));
end

function P = perspective_projection(f)
% Returns a 4x3 full-perspective projection matrix.
%
% Parameters:
% f -- Focal length.

P = [f, 0, 0, 0;
     0, f, 0, 0;
     0, 0, 1, 0];

end

function edges = hierarchy_to_edges(hierarchy)

% Make a column vector.
hierarchy = shiftdim(hierarchy);

% Construct list of edge pairs.
n = length(hierarchy);
edges = [hierarchy(2:n), (2:n)'];

end

function s = enum(names, values)
% Constructs a Matlab pseudo-enum-thing.
% Parameters:
% names -- Vector of cells, each containing a string.
% values (optional) -- Value to associate with each name. Incremental from 1 by
%   default.

assert(iscell(names));

n = length(names);

if exist('values', 'var')
  assert(length(values) == n);
else
  values = 1:n;
end

args = [names(:), arrayfun(@(x) {x}, values(:))]';
s = struct(args{:});

end

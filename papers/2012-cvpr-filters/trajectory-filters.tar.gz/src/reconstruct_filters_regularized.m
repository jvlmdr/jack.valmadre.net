% Minimizes filter prior regularized by projection error.
%
% Parameters:
% trajectory -- Vector of observations of point.
% filters -- Cell array of filter vectors.
% lambda -- Penalty for violating reconstruction error.

function x = reconstruct_filters_regularized(trajectory, filters, lambda)
  num_frames = trajectory.num_frames;

  % Get full system of equations.
  equations = trajectory_projection_equations(trajectory);
  [Q, u] = independent_to_full(equations, num_frames);
  m = size(Q, 1) / 2;
  % Normalization is more important in the regularized case.
  Q = Q / m;
  u = u / m;

  % Construct a convolution matrix.
  G = filter_bank_matrix(filters, num_frames, 'valid');
  G = G / num_frames;

  x = reconstruct_linear_regularized(Q, u, G, lambda);
  x = reshape(x, [3, num_frames]);
end

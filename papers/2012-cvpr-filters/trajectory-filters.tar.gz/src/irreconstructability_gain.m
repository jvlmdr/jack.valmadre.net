% Returns the gain term in reconstructability.

function g = irreconstructability_gain(Q_null, E)
  V = kron(E, eye(3));
  M = V' * V;

  A = Q_null' * M * Q_null;
  g = cond(A);
end

function experiment = solver_experiment_run(data)
  % Extract some mocap data.
  [num_sequences, num_omegas] = size(data.scenes);
  [num_frames, num_points, three] = size(data.points);

  % Thresholds for condition of matrix.
  max_gains = [3, 10, 100, 1e3, 1e4, 1e5];
  max_gains_text = {'3', '10^1', '10^2', '10^3', '10^4', '10^5'};
  % Filters.
  filter_banks = {{[1, -1]}, {[-1, 2, -1]}, {[1, -1], [-1, 2, -1]}};
  % Basis sizes.
  basis_sizes = [1, 2, 4, 8, 16, 32, 64];
  %basis_sizes = exp(linspace(log(1), log(floor(2 / 3 * num_frames)), 8));
  %basis_sizes = unique(round(basis_sizes));
  % L1 regularisers.
  %lambdas = 10 .^ (3:5);
  lambdas = 10 .^ (2:6); %(-2:2:6);

  % Prepare function handles for each solver.
  basis_solvers = arrayfun(@(K) {@(x) reconstruct_dct(x, K)}, basis_sizes);
  sparse_solvers = arrayfun(...
      @(lambda) {@(x) reconstruct_sparse_dct(x, lambda)}, lambdas);
  auto_basis_solvers = arrayfun(@(g) {@(x) reconstruct_dct_auto(x, g)}, ...
      max_gains);
  filter_solvers = cellfun(...
      @(filters) {@(x) reconstruct_filters(x, filters)}, filter_banks);
  solvers = [basis_solvers, sparse_solvers, auto_basis_solvers, filter_solvers];

  % Give each solver a name.
  basis_names = arrayfun(@(x) {['K = ', num2str(x)]}, basis_sizes);
  sparse_names = arrayfun(...
      @(x) {sprintf('\\lambda = 10^{%d}', log10(x))}, lambdas);
  auto_basis_names = cellfun(...
      @(x) {sprintf('\\gamma < %s', x)}, max_gains_text);
  filter_names = {'[1, -1]', '[-1, 2, -1]', '[1, -1], [-1, 2, -1]'};
  solver_names = [basis_names, sparse_names, auto_basis_names, filter_names];

  num_dct = length(basis_sizes);
  num_sparse = length(lambdas);
  num_auto = length(max_gains);
  num_filters = length(filter_banks);

  % Group solvers into sets.
  offset = 0;
  dct_subset = offset + (1:num_dct);
  offset = offset + length(basis_sizes);
  sparse_subset = offset + (1:num_sparse);
  offset = offset + length(lambdas);
  dct_auto_subset = offset + (1:num_auto);
  offset = offset + length(max_gains);
  filters_subset = offset + (1:num_filters);
  subsets = {dct_subset, sparse_subset, dct_auto_subset, filters_subset};
  subset_names = {'dct', 'sparse', 'auto', 'filters'};

  % Specify colors for each solver.
  basis_colors = color_gradient([0, 0.8, 0], [0, 0.4, 1], num_dct);
  sparse_colors = color_gradient([1, 0.8, 1], [0.2, 0, 0.2], num_sparse);
  auto_basis_colors = color_gradient([1, 0.8, 0], [0.4, 0.2, 0], num_auto);
  filter_colors = color_gradient([1, 0.6, 0.2], [0.8, 0, 0], num_filters);
  solver_colors = [basis_colors; sparse_colors; auto_basis_colors; ...
      filter_colors];

  % Run each solver once to catch an error before attempting everything.
  f = @(x) arrayfun(@(y) solver_trial(y, solvers, solver_names), x);
  % Run the solvers. Use parallelize() if it's available.
  if exist('parallelize', 'file')
    % Following lines test each solver locally before parallelizing.
    fprintf('Running each solver once to test...\n');
    f(data.scenes(1));
    fprintf('Running for real...\n');

    config = struct('virtual_free', '128M');
    results = parallelize(f, data.scenes, numel(data.scenes), 'v', config);
  else
    warning('Could not find parallelize(), running in series.');
    results = f(data.scenes);
  end

  experiment = struct('data', data, 'results', results, ...
      'solver_names', {solver_names}, 'solver_colors', {solver_colors}, ...
      'solver_subsets', {subsets}, 'solver_subset_names', {subset_names});
end

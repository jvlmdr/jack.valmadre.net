% Minimizes projection error regularized by sparsity.
%
% Parameters:
% trajectory -- Vector of observations of point.
% basis -- Basis to promote sparsity over.
% lambda -- Weight for L1 objective term.

function [x, b] = reconstruct_sparse(trajectory, basis, lambda)
  F = trajectory.num_frames;

  % Get full system of equations.
  equations = trajectory_projection_equations(trajectory);
  [Q, u] = independent_to_full(equations, F);

  % Construct 3D basis.
  theta = kron(basis, eye(3));

  % Solve for the sparse coefficients.
  b = l1ls_featuresign(Q * theta, u, lambda);
  %b = l1_ls(Q * theta, u, lambda, 1e-3, true);

  x = theta * b;
  x = reshape(x, [3, F]);
end

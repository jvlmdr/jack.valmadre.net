function H = conv_matrix(h, n, shape)
  % Returns a matrix which represents convolution with h.
  %
  % Parameters:
  % h -- Convolution kernel, vector of length m.
  % n -- Size of sequence to convolve with.
  % shape -- Determines type of convolution matrix returned.
  %   'full'  -- Returns full linear convolution, length (n + m - 1).
  %   'valid' -- Returns only parts which overlap, length (n - m + 1).
  %   'circ'  -- Returns result assuming kernel has period n, length n.
  %              Equivalent to ifft(fft(h) .* fft(x)).

  h = h(:);
  m = length(h);

  if strcmpi(shape, 'full')
    r = [h(1); zeros(n - 1, 1)];
    c = [h; zeros(n - 1, 1)];
  elseif strcmpi(shape, 'valid')
    r = [h(m:-1:1); zeros(n - m, 1)];
    c = [h(m); zeros(n - m, 1)];
  elseif strcmpi(shape, 'circ')
    r = [h(1); zeros(n - m, 1); h(m:-1:2)];
    c = [h; zeros(n - m, 1)];
  else
    error('shape must be ''full'', ''valid'' or ''circ''');
  end

  H = toeplitz(sparse(c), sparse(r));
end

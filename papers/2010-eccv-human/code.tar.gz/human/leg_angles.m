function q = leg_angles(bones, mirror)

% Normalize coordinate system to torso.
torso = bones{1}';
R_torso = normalize_torso(torso, 1:3);
bones = cellfun(@(X) {(R_torso * X')'}, bones);

% Reflect x co-ordinate for right leg.
if mirror
  bones = cellfun(@(X) {X * diag([-1, 1, 1])}, bones);
end

% Tibia, knee, femur <=> humerus, elbow, radius!
femur = bones{2}';
tibia = bones{3}';
[q_leg, R_leg] = elbow_angles(femur, tibia);

% Undo the preceding joints and find foot angles.
foot = bones{4}';
foot = R_leg' * foot;
q_foot = foot_angles(foot);

% Concatenate angles.
q = [q_leg; q_foot];

end

function lengths = min_lengths(points, scales, edges, symmetry)

F = size(points, 1) / 2;
N = size(points, 2);
E = size(edges, 1);

% Reshape for scaling.
points = reshape(points, [F, 2 * N]);
points = diag(1 ./ scales) * points;

% Reshape then calculate lengths.
points = reshape(points, [F, 2, N]);
lengths = zeros(F, E);
for t = 1:F
  x = reshape(points(t, :, :), [2, N])';
  lengths(t, :) = edge_lengths(x', edges);
end

% Take longest observed projection as true length.
lengths = max(lengths, [], 1)';

if ~isempty(symmetry)
  % Take maximum length over symmetrical pairs.
  pair_lengths = max(lengths(symmetry), [], 2);
  lengths(symmetry(:, 1)) = pair_lengths;
  lengths(symmetry(:, 2)) = pair_lengths;
end

end

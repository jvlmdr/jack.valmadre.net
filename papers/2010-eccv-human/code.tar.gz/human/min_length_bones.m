function bones = min_length_bones(points, scales, edges, symmetry)
%
% Parameters:
% points -- num_frames x num_joints x 2.
% scales -- Vector of length num_frames.

F = size(points, 1) / 2;
N = size(points, 2);
E = size(edges, 1);

% Find minimum length of all bones.
lengths = min_lengths(points, scales, edges, symmetry);

% Calculate x and y component of projected edges.
% num_frames x num_joints x 2 => num_frames x 2 x num_joints
points = permute(points, [1, 3, 2]);
% num_frames x 2 x num_joints => (num_frames x 2) x num_joints
points = reshape(points, [2 * F, N]);
% Take edges between 2D points.
bones = edge_vectors(points, edges);
% (num_frames x 2) x num_edges => num_frames x (2 x num_edges)
bones = reshape(bones, [F, 2 * E]);
% Undo scale.
bones = diag(1 ./ scales) * bones;
% num_frames x (2 x num_edges) => num_frames x 2 x num_edges
bones = reshape(bones, [F, 2, E]);

% Calculate z component.
l = reshape(ones(F, 1) * lengths', [F, 1, E]);
x2 = sum(bones.^2, 2);
z = sqrt(max(l.^2 - x2, 0));
bones = cat(2, bones, z);

end

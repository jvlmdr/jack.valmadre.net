function compare_directions(this, frame, part)

ambiguous_pose = this.ambiguous_poses(frame);

for i = 1:2
  direction = i - 1;
  
  copy = ambiguous_pose.copy();
  copy.set_direction(part, direction);
  
  % Show image.
  subplot(2, 2, i);
  this.projections.show_frame(frame, false);
  
  % Render skeleton with direction set.
  subplot(2, 2, i + 2);
  copy.render(part);
end

end

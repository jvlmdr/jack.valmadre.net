function resolve(this)
% Interactively resolves ambiguity in a pose solution.

num_frames = length(this.ambiguous_poses);

finished = false;
frame = -1;

while ~finished
  % Possible frames to choose from.
  frames = this.ambiguous_frames();

  if isempty(frames)
    % There are no ambiguous frames!
    finished = true;
  else
    % There are still frames that need resolving.
    % Show the user the frames.
    clf;
    this.projections.show_frames(frames, false);

    % Choose a frame to resolve.
    fprintf('\nWhich image would you like to resolve?\n');
    for i = frames
      fprintf('  %d) image %d,\n', i, i);
    end
    fprintf('  0) or stop resolving ambiguities?\n\n');

    frame = -1;
    % Keep asking until we get a good response.
    while ~(frame == 0 || any(frames == frame))
      frame = int32(input('Choose a frame: '));
    end

    if frame > 0
      resolve_frame(this, frame);
    else
      finished = true;
    end
  end
end

end


function resolve_frame(this, frame)

ambiguous_pose = this.ambiguous_poses(frame);
finished = false;

while ~finished
  % Which parts are ambiguous?
  parts = ambiguous_pose.ambiguous_parts();

  if isempty(parts)
    finished = true;
  else
    % Show the user the frame they chose.
    clf;
    subplot(1, 2, 1);
    this.projections.show_frame(frame, true);
    subplot(1, 2, 2);
    ambiguous_pose.render();

    % Ask the user to choose a part.
    fprintf('\nWhich part would you like to specify?\n');
    for i = parts
      name = ambiguous_pose.pose.model.part_names{i};
      fprintf('  %d) %s,\n', i, name);
    end
    fprintf('  0) or go back?\n\n');

    % Prompt the user for a part until they give one.
    part = -1;
    while ~(any(parts == part) || part == 0)
      part = int32(input('Choose a part: '));
    end

    if part > 0
      resolve_part(this, frame, part);
    else
      finished = true;
    end
  end
end

end


function resolve_part(this, frame, part)

ambiguous_pose = this.ambiguous_poses(frame);

% Display both directions for comparison.
this.compare_directions(frame, part);

% Ask the user to pick one.
fprintf('\nShould the part go\n');
fprintf('  1) forwards,\n');
fprintf('  2) backwards,\n');
fprintf('  0) or would you like to go back?\n\n');

% Prompt the user for a part until they give one.
direction = -1;
while ~(direction >= 0 && direction <= 2)
  direction = int32(input('Choose a direction: '));
end

if direction > 0
  % User specified a direction.
  ambiguous_pose.set_direction(part, direction - 1);
end

end

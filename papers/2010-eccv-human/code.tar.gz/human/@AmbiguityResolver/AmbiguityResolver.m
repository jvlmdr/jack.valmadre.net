classdef AmbiguityResolver < handle
  % Resolves the ambiguity of an ambiguous pose with user input.
  
  properties
    % Ambiguous pose to resolve.
    ambiguous_poses
    % Projections from which the poses came.
    projections
  end
  
  methods
    function this = AmbiguityResolver(ambiguous_poses, projections)
      % Constructs an object to help the user resolve depth ambiguities.
      %
      % Parameters:
      % ambiguous_poses -- Ambiguous 3D poses to resolve.
      % projections -- Projections from which the poses came.
      this.ambiguous_poses = ambiguous_poses;
      this.projections = projections;
    end

    function frames = ambiguous_frames(this)
      ambiguous = arrayfun(@(x) x.is_ambiguous(), this.ambiguous_poses);
      frames = find(ambiguous(:)');
    end
  end
end

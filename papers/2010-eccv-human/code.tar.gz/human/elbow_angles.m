function [q, R] = elbow_angles(humerus, radius)
% Parameters:
% humerus -- 3x1 left-humerus vector.
% radius -- 3x1 left-radius vector.

% Obtain vector normal to plane created by elbow joint.
n = cross(humerus, radius);
% Find y and z angles at shoulder.
q1 = atan2(n(2), n(1));
q2 = atan2(-n(3), sqrt(n(1)^2 + n(2)^2));
% Note: Could test validity of q1 here before continuing.

% Undo rotation of q1 and q2.
R = rotz(q1) * roty(q2);
humerus = R' * humerus;
radius = R' * radius;
% Find x rotations at shoulder and elbow.
q3 = atan2(-humerus(3), -humerus(2));
q4 = atan2(norm(cross(humerus, radius)), dot(humerus, radius));

q = [q1; q2; q3; q4];

if nargout > 1
  % Return full rotation transform.
  R = R * rotx(q3) * rotx(q4);
end

end

function ambiguous_poses = find_poses(projections)

model = projections.model;
num_frames = projections.num_frames;
num_joints = model.num_joints;

% Extract rigid subset of points.
rigid_joints = model.parts{model.torso_part};
U = projections.points(:, rigid_joints, 1);
V = projections.points(:, rigid_joints, 2);
W = [U; V];

% Solve rigid part of structure.
[rigid_points, scales] = sfm_factorization(W);
% Undo scale.
rigid_points(:, :) = diag(1 ./ scales) * rigid_points(:, :);

% Extract all points.
U = projections.points(:, :, 1);
V = projections.points(:, :, 2);
W = [U; V];
% Find the edges that define the free bones.
edges = model.bone_edges(1:num_joints-1);
edge_symmetry = model.symmetric_bones;
% Find minimum lengths of free bones to satisfy projections.
bones = min_length_bones(W, scales, edges, edge_symmetry);

% Find relative bones in rigid structure.
i = model.part_bones(model.torso_part);
edges = model.bone_edges(i);
num_edges = length(i);
% Unpack points back into normal indices before finding edges.
points = zeros(num_frames, 3, num_joints);
points(:, :, rigid_joints) = rigid_points;
% Find edges across all frames.
points = reshape(points, [3 * num_frames, num_joints]);
rigid_bones = edge_vectors(points, edges);
% Replace minimum-length solution for rigid bones.
rigid_bones = reshape(rigid_bones, [num_frames, 3, num_edges]);
bones(:, :, i) = rigid_bones;

ambiguous_poses = AmbiguousPose([num_frames, 1]);
for t = 1:num_frames
  frame_bones = reshape(bones(t, :, :), [3, num_joints - 1])';
  pose = Pose(model, frame_bones);
  ambiguous_poses(t) = AmbiguousPose(pose, []);
end

end

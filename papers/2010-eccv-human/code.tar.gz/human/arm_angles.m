function theta = arm_angles(bones, mirror)

% Normalize coordinate system to torso.
torso = bones{1}';
R_torso = normalize_torso(torso, 1:3);
bones = cellfun(@(X) {(R_torso * X')'}, bones);

% Reflect x coordinate for right arm.
if mirror
  bones = cellfun(@(X) {X * diag([-1, 1, 1])}, bones);
end

% Apply extra arm transform.
R_arm = rotz(-pi/2) * rotx(pi);
% Apply inverse transform to get into arm space.
bones = cellfun(@(X) {(R_arm' * X')'}, bones);

% Extract humerus and radius and fine angles.
humerus = bones{2}';
radius = bones{3}';
theta = elbow_angles(humerus, radius);

end

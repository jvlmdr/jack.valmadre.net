function [q, R] = head_angles(head)

% Find angles giving head position.
q1 = atan2(-head(1), head(2));
q2 = atan2(head(3), sqrt(head(1)^2 + head(2)^2));
q = [q1; q2];

if nargout > 1
  % Rotation transform to end point.
  R = rotz(q1) * rotx(q2);
end

end

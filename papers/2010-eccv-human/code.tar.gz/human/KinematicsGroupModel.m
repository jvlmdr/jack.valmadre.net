classdef KinematicsGroupModel < handle
  % Describes a group of parts with independent inverse kinematics.
  
  properties
    % Vector of part indices.
    parts
    num_parts
    % Function to solve inverse kinematics.
    solve
    % Number of angles returned by inverse kinematics function.
    num_angles
  end
  
  methods
    function this = KinematicsGroupModel(parts, solve, num_angles)
      num_parts = length(parts);

      this.parts = parts;
      this.num_parts = num_parts;
      this.solve = solve;
      this.num_angles = num_angles;
    end

    function group = create(this, pose)
      % Extract bones for each part.
      bone_indices = arrayfun(@(i) {pose.model.part_bones(i)}, this.parts);
      bone_vectors = cellfun(@(i) {pose.bones(i, :)}, bone_indices);

      group = KinematicsGroup(this, bone_vectors);
    end
  end
end

classdef AmbiguousPose < handle
  % Describes the depth ambiguities in a 3D pose.
  
  properties
    % Poses that the ambiguity refers to.
    pose
    % Forced directions. num_frames x num_parts
    % 1, -1 and 0 indicate forward, backward and neutral.
    directions
  end
  
  methods
    function this = AmbiguousPose(pose, directions)
      % Constructs a human pose with ambiguity.
      %
      % Parameters:
      % pose -- The 3D pose to add ambiguity to.
      % directions -- Directions to fix. Empty matrix for none.
      if nargin == 2
        this.pose = pose;
        if isempty(directions)
          num_parts = pose.model.num_parts;
          this.directions = zeros(num_parts, 1);
        else
          this.directions = directions;
        end
      elseif nargin == 1
        sz = pose;
        this(prod(sz)) = AmbiguousPose();
        this = reshape(this, sz);
      elseif nargin > 0
        error('Wrong number of arguments');
      end
    end
    
    function this = copy(other)
      this = AmbiguousPose(other.pose, other.directions);
    end
  end
end

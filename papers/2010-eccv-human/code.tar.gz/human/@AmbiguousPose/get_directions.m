function directions = get_directions(this, part)
% Returns the possible directions a part can take.
%
% Returns:
% 0, 1 or [0, 1]

EPSILON = 1e-2;

% Check if the part is forced to be in a particular direction.
forced = this.directions(part);

if forced > 0
  directions = 0;
elseif forced < 0
  directions = 1;
else
  % Check if the part has a significant z component.
  i = this.pose.model.part_bones(part);
  num_bones = length(i);
  bones = this.pose.bones(i, :);
  l = sqrt(sum(bones .^ 2, 2));
  z = this.pose.bones(i, 3);
  
  if all(abs(z ./ l) <= EPSILON)
    % Direction doesn't mean anything. Pick either one.
    directions = 0;
  else
    % Both directions should be considered.
    directions = [0, 1];
  end
end

end

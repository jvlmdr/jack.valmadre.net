function parts = ambiguous_parts(this)
% Returns a list of all parts which have direction ambiguity.

num_parts = this.pose.model.num_parts;

% Check if any of the parts are ambiguous.
parts = 1:num_parts;
ambiguous = arrayfun(@(i) this.part_is_ambiguous(i), parts);
parts = find(ambiguous);

end

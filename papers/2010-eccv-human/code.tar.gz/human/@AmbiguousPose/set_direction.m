function set_direction(this, part, direction)
% Sets the direction of a part.
%
% Parameters:
% part -- Index of the part/s in the skeleton model.
% direction -- 0 for unchanged, 1 for flip. Must be same size as part.

% Set the given direction.
this.directions(part) = (-1) .^ direction;

end

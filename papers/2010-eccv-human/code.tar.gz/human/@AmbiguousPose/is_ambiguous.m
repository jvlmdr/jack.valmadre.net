function ambiguous = is_ambiguous(this)
% Returns true if any of the parts are ambiguous, false otherwise.

num_parts = this.pose.model.num_parts;

% Check if any of the parts are ambiguous.
parts = 1:num_parts;
ambiguous = arrayfun(@(i) this.part_is_ambiguous(i), parts);
ambiguous = any(ambiguous);

end

function ambiguous = part_is_ambiguous(this, part)

ambiguous = length(this.get_directions(part)) > 1;

end

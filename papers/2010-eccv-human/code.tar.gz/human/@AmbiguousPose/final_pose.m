function pose = final_pose(this)
% Returns the 3D joint positions from a frame, in pixel space.

if this.is_ambiguous()
  error('Pose is ambiguous');
end

model = this.pose.model;
num_parts = model.num_parts;
bones = this.pose.bones;

for part = 1:model.num_parts
  % Which bones are in this part?
  i = model.part_bones(part);
  % Get the direction of this part.
  direction = this.get_directions(part);
  % Apply the direction to the bones.
  bones(i, 3) = (-1) ^ direction * bones(i, 3);
end

pose = Pose(model, bones);

end

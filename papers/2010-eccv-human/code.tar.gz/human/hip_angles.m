function q = hip_angles(bones)

% Normalize coordinate system to torso.
torso = bones{1}';
R_torso = normalize_torso(torso, 1:3);
bones = cellfun(@(X) {(R_torso * X')'}, bones);

% Extract bone vectors.
lhip = bones{2}';
rhip = bones{3}';

% Find angles to midpoint
midpoint = 0.5 * (lhip + rhip);
% Rotate 180 degrees about x.
R_hip = rotx(pi);
midpoint = R_hip' * midpoint;

% Now the problem is equivalent to a head!
q = head_angles(midpoint);
% Except the direction of the z angle is flipped.
q(1) = -q(1);

end

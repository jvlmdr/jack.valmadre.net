function [q, R] = neck_angles(bones)

% Normalize coordinate system to torso.
torso = bones{1}';
R_torso = normalize_torso(torso, 1:3);
bones = cellfun(@(X) {(R_torso * X')'}, bones);

% Extract neck and head vectors.
neck = bones{2}';
head = bones{3}';

% Solve for neck angles.
[q_neck, R_neck] = head_angles(neck);

% Undo neck rotation and treat head as same problem again.
head = R_neck' * head;
q_head = head_angles(head);

% Concatenate angle vectors.
q = [q_neck; q_head];

end

function [model, kinematics] = wei_chai_model()
% Returns the skeleton model used by Wei and Chai.

num_joints = 18;

WAIST = 1;
CHEST = 2;
LEFT_SHOULDER = 3;
LEFT_ELBOW = 4;
LEFT_WRIST = 5;
RIGHT_SHOULDER = 6;
RIGHT_ELBOW = 7;
RIGHT_WRIST = 8;
NECK_JOINT = 9;
HEAD_JOINT = 10;
LEFT_HIP_JOINT = 11;
LEFT_KNEE = 12;
LEFT_ANKLE = 13;
LEFT_TOES = 14;
RIGHT_HIP_JOINT = 15;
RIGHT_KNEE = 16;
RIGHT_ANKLE = 17;
RIGHT_TOES = 18;

% Connect each joint to the previous joint...
joint_hierarchy = (1:num_joints) - 1;
% ...except...
joint_hierarchy(LEFT_SHOULDER) = CHEST;
joint_hierarchy(RIGHT_SHOULDER) = CHEST;
joint_hierarchy(NECK_JOINT) = CHEST;
joint_hierarchy(LEFT_HIP_JOINT) = WAIST;
joint_hierarchy(RIGHT_HIP_JOINT) = WAIST;

% Name to display for each joint.
joint_names = {...
  'Waist', 'Chest', ...
  'Left Shoulder', 'Left Elbow', 'Left Wrist', ...
  'Right Shoulder', 'Right Elbow', 'Right Wrist', ...
  'Neck', 'Head', ...
  'Left Hip', 'Left Knee', 'Left Ankle', 'Left Toes', ...
  'Right Hip', 'Right Knee', 'Right Ankle', 'Right Toes', ...
};

% Name to display for each bone.
% bone_names{i - 1} is the bone connecting joint_hierarchy(i) to joint i.
bone_names = {...
  'Back', ...
  'Left Clavicle', 'Left Humerus', 'Left Radius', ...
  'Right Clavicle', 'Right Humerus', 'Right Radius', ...
  'Neck', 'Head', ...
  'Left Hip', 'Left Femur', 'Left Tibia', 'Left Foot', ...
  'Right Hip', 'Right Femur', 'Right Tibia', 'Right Foot', ...
};

% Pairs of bones of equal length.
symmetric_bones = [
  LEFT_SHOULDER, RIGHT_SHOULDER;
  LEFT_ELBOW, RIGHT_ELBOW;
  LEFT_WRIST, RIGHT_WRIST;
  LEFT_HIP_JOINT, RIGHT_HIP_JOINT;
  LEFT_KNEE, RIGHT_KNEE;
  LEFT_ANKLE, RIGHT_ANKLE;
  LEFT_TOES, RIGHT_TOES
];
symmetric_bones = symmetric_bones - 1;

% Define the rigid parts which comprise the body.
num_parts = 15;

TORSO = 1;
LEFT_HUMERUS = 2;
LEFT_RADIUS = 3;
RIGHT_HUMERUS = 4;
RIGHT_RADIUS = 5;
NECK = 6;
HEAD = 7;
LEFT_HIP = 8;
LEFT_FEMUR = 9;
LEFT_TIBIA = 10;
LEFT_FOOT = 11;
RIGHT_HIP = 12;
RIGHT_FEMUR = 13;
RIGHT_TIBIA = 14;
RIGHT_FOOT = 15;

parts = {};
parts{TORSO} = [WAIST, CHEST, LEFT_SHOULDER, RIGHT_SHOULDER];
parts{LEFT_HUMERUS} = [LEFT_SHOULDER, LEFT_ELBOW];
parts{LEFT_RADIUS} = [LEFT_ELBOW, LEFT_WRIST];
parts{RIGHT_HUMERUS} = [RIGHT_SHOULDER, RIGHT_ELBOW];
parts{RIGHT_RADIUS} = [RIGHT_ELBOW, RIGHT_WRIST];
parts{NECK} = [CHEST, NECK_JOINT];
parts{HEAD} = [NECK_JOINT, HEAD_JOINT];
parts{LEFT_HIP} = [WAIST, LEFT_HIP_JOINT];
parts{LEFT_FEMUR} = [LEFT_HIP_JOINT, LEFT_KNEE];
parts{LEFT_TIBIA} = [LEFT_KNEE, LEFT_ANKLE];
parts{LEFT_FOOT} = [LEFT_ANKLE, LEFT_TOES];
parts{RIGHT_HIP} = [WAIST, RIGHT_HIP_JOINT];
parts{RIGHT_FEMUR} = [RIGHT_HIP_JOINT, RIGHT_KNEE];
parts{RIGHT_TIBIA} = [RIGHT_KNEE, RIGHT_ANKLE];
parts{RIGHT_FOOT} = [RIGHT_ANKLE, RIGHT_TOES];

part_names{TORSO} = 'Torso';
part_names{NECK} = 'Neck';
part_names{HEAD} = 'Head';
part_names{LEFT_HUMERUS} = 'Left Humerus';
part_names{LEFT_RADIUS} = 'Left Radius';
part_names{RIGHT_HUMERUS} = 'Right Humerus';
part_names{RIGHT_RADIUS} = 'Right Radius';
part_names{LEFT_HIP} = 'Left Hip';
part_names{LEFT_FEMUR} = 'Left Femur';
part_names{LEFT_TIBIA} = 'Left Tibia';
part_names{LEFT_FOOT} = 'Left Foot';
part_names{RIGHT_HIP} = 'Right Hip';
part_names{RIGHT_FEMUR} = 'Right Femur';
part_names{RIGHT_TIBIA} = 'Right Tibia';
part_names{RIGHT_FOOT} = 'Right Foot';

% Connect each part to the previous part...
part_hierarchy = (1:num_parts) - 1;
% ...except...
part_hierarchy(LEFT_HUMERUS) = TORSO;
part_hierarchy(RIGHT_HUMERUS) = TORSO;
part_hierarchy(NECK) = TORSO;
part_hierarchy(LEFT_HIP) = TORSO;
part_hierarchy(RIGHT_HIP) = TORSO;

% Construct skeleton model.
model = SkeletonModel(num_joints, joint_hierarchy, joint_names, bone_names, ...
  symmetric_bones, parts, part_hierarchy, part_names, TORSO, HEAD);

% Define kinematics of skeleton.
% x is normal to chest, y is downwards and parallel to the back, z is along arm.
ARM_BOUNDS = pi / 180 * [...
   -120,  90;  ... humerus z
   -60, 120;  ... humerus y
  -100, 100;  ... humerus x
     0, 170;  ... radius x
];

LEG_BOUNDS = pi / 180 * [...
   -60,  60;  ... femur z
   -90,  90;  ... femur y
  -160,  60;  ... femur x
     0, 170;  ... tibia x
   -90,  60;  ... foot z
   -60,  90;  ... foot x
];

NECK_BOUNDS = pi / 180 * [...
  -90, 90;  ... neck z
  -45, 60;  ... neck x
  -90, 90;  ... head z
  -60, 90;  ... head x
];

HIP_BOUNDS = pi / 180 * [...
  -70, 70;  ... hip z (bend sideways)
  -30, 90;  ... hip x (bend over)
];

groups = [...
  KinematicsGroupModel([TORSO, LEFT_HUMERUS, LEFT_RADIUS], ...
    @(x) arm_angles(x, false), 4), ...
  KinematicsGroupModel([TORSO, RIGHT_HUMERUS, RIGHT_RADIUS], ...
    @(x) arm_angles(x, true), 4), ...
  KinematicsGroupModel([TORSO, LEFT_HIP, RIGHT_HIP], ...
    @(x) hip_angles(x), 2), ...
  KinematicsGroupModel([TORSO, LEFT_FEMUR, LEFT_TIBIA, LEFT_FOOT], ...
    @(x) leg_angles(x, false), 6), ...
  KinematicsGroupModel([TORSO, RIGHT_FEMUR, RIGHT_TIBIA, RIGHT_FOOT], ...
    @(x) leg_angles(x, true), 6), ...
  KinematicsGroupModel([TORSO, NECK, HEAD], @(x) neck_angles(x), 4), ...
];

limits = {...
  ARM_BOUNDS, ARM_BOUNDS, HIP_BOUNDS, LEG_BOUNDS, LEG_BOUNDS, NECK_BOUNDS, ...
};

kinematics = BodyKinematics(groups, limits);

end

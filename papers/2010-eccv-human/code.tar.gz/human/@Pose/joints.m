function points = joints(this)
% Returns the 3D position of the skeleton's joints.

num_joints = this.model.num_joints;
points = zeros(num_joints, 3);

for j = 2:num_joints
  i = this.model.joint_hierarchy(j);
  
  joint = points(i, :)';
  bone = this.bones(j - 1, :)';
  points(j, :) = joint + bone;
end

end

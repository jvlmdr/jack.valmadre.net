classdef Pose < handle
  % Describes a collection of 3D poses.
  
  properties
    % The human body model.
    model
    % The 3D vectors representing bones.
    % 3D matrix: (num_joints - 1) x 3
    bones
  end
  
  methods
    function this = Pose(model, bones)
      if nargin == 2
        this.model = model;
        this.bones = bones;
      elseif nargin == 1
        sz = model;
        this(prod(sz)) = Pose();
        this = reshape(this, sz);
      elseif nargin > 0
        error('Wrong number of arguments');
      end
    end
  end
end

function render(this, color, alpha)

thickness = 0.1 * norm(this.bones(1, :));

num_joints = this.model.num_joints;
points = this.joints();

for j = 2:num_joints
  i = this.model.joint_hierarchy(j);
  joint = points(i, :)';
  bone = this.bones(j - 1, :)';

  render_bone(joint, bone, thickness, color, alpha);
  hold on;
end
hold off;

axis image;

end

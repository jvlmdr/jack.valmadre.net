function prune_invalid(this)

num_parts = this.pose.model.num_parts;
num_groups = this.num_groups;
changed = true;

% Keep repeating pruning until no changes are made.
while changed
  % Before doing anything, no changes have been made.
  changed = false;
  part = 1;
  % Keep looking for a part to prune until one changes.
  while ~changed && part <= num_parts
    % Check whether this part is ambiguous.
    directions = this.get_directions(part);

    if length(directions) > 1
      % Find minimum number of solutions across all groups containing the part.
      min_valid = inf(1, 2);
      % Find groups which contain this part.
      %groups = this.kinematics.groups_containing_part(part);
      for j = 1:num_groups
        group = this.groups(j);

        % Check if group contains part.
        part_index = find(group.model.parts == part);
        if ~isempty(part_index)
          % Check how many valid solutions there are for each direction.
          num_valid = zeros(1, 2);
          for k = 1:2
            direction = k - 1;

            % Find which combinations are still possible.
            possible = this.possible_combinations(j);
            % Find combinations which have this part in this direction.
            match = (group.combinations(:, part_index) == direction);
            % Which combinations match, are possible and are valid.
            num_valid(k) = sum(and(and(possible, match), this.valid{j}));
          end
          min_valid = min(min_valid, num_valid);
        end
      end

      % Check whether exactly one direction is entirely invalid.
      if length(find(min_valid == 0)) == 1
        for k = 1:2
          % Set opposite direction.
          direction = 1 - (k - 1);
          if min_valid(k) == 0
            this.set_direction(part, direction);
          end
        end
        changed = true;
      end
    end

    part = part + 1;
  end
end

end

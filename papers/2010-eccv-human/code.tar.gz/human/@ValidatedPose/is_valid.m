function result = is_valid(this, part, direction)

result = true;
model = this.pose.model;

% Search over all groups which include this part.
% (part, direction) is invalid if any group has all invalid solutions, or
% (part, direction) is invalid if not all groups have a valid solution.
for i = 1:this.num_groups
  group = this.groups(i);

  % Find which part number within the group corresponds to the given part.
  index = find(group.model.parts == part);
  if isempty(index)
    % Group does not contain this part.
    continue;
  end

  % Find all solutions which have matching direction for this part.
  mask = (group.combinations(:, index) == direction);
  valid = this.valid{i}(mask);

  if all(not(valid))
    % All of the solutions for (part, direction) are invalid.
    result = false;
    return;
  end
end

end

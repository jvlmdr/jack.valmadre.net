classdef ValidatedPose < AmbiguousPose
  % Describes an ambiguous pose that has had all solutions validated.
  
  properties
    groups
    num_groups
    valid
  end
  
  methods
    function this = ValidatedPose(pose, directions, groups, valid)
      % Conditional calls to superclass constructor not allowed.
      args = {};
      if nargin == 4
        args = {pose, directions};
      end
      this = this@AmbiguousPose(args{:});

      if nargin == 4
        num_groups = length(groups);
        assert(length(valid) == num_groups, ...
          'Must have same number of groups and validity tables');

        this.groups = groups;
        this.num_groups = num_groups;
        this.valid = valid;
      elseif nargin == 1
        sz = pose;
        this(prod(sz)) = ValidatedPose();
        this = reshape(this, sz);
      elseif nargin > 0
        error('Wrong number of arguments');
      end
    end

    function this = copy(other)
      % Creates a copy of this validated pose.
      this = ValidatedPose(other.pose, other.directions, other.groups, ...
        other.valid);
    end
  end
end

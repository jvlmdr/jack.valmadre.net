function possible = possible_combinations(this, group_index)
% Returns indices of group combinations that are still possible.
% A combination becomes impossible when the user sets a part direction which
% contradicts that particular combination.

group = this.groups(group_index);

% Get parts which comprise the group.
parts = group.model.parts;
num_parts = length(parts);
num_combinations = 2 ^ num_parts;
% Get original list of combinations.
combs = group.combinations;

% Build a boolean mask stating whether that combination is possible.
possible = false(num_combinations, num_parts);

for i = 1:num_parts
  part = parts(i);
  solutions = combs(:, i);

  % Get the possible directions for this part.
  directions = this.get_directions(part);
  num_directions = length(directions);

  % Compare each direction to the combinations.
  solutions = solutions * ones(1, num_directions);
  directions = ones(num_combinations, 1) * directions;

  % If the solution is equal to any of the possible directions, include it.
  possible(:, i) = any(solutions == directions, 2);
end

% All parts must agree that a combination is possible.
possible = all(possible, 2);

end

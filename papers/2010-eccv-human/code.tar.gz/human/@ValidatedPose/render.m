function render(this, highlight)
% Renders an ambiguous 3D pose with kinematic validation.
%
% Parameters:
% highlight -- Parts to highlight (optional).

% Visual configuration.
if ~exist('highlight', 'var')
  highlight = [];
end
options.thickness = 0.1 * norm(this.pose.bones(1, :));
options.highlight = highlight;
options.color = [0, 0.8, 0];
options.highlight_color = [0, 0.4, 0.8];
options.invalid_color = [0.8, 0.2, 0.2];

% Joint positions are originally unknown.
model = this.pose.model;
num_joints = model.num_joints;
points = zeros(num_joints, 3);

% Recursively render parts.
render_part(this, 1, true, points, options);
hold off;

axis image;

view(45, 30);
camlight(0, 0);
lighting phong;

end


function bounds = render_part(this, part, valid, points, options)

model = this.pose.model;
bounds = [];

% Find which directions are possible for this part.
directions = this.get_directions(part);

for z = 1:length(directions)
  % Create a copy of the joint positions.
  new_points = points;
  % Get all bones within this part.
  part_bones = model.part_bones(part);
  edges = model.bone_edges(part_bones);
  num_bones = length(part_bones);

  % Check whether this direction has become invalid.
  valid_direction = (valid && this.is_valid(part, directions(z)));
  valid_direction = (valid_direction || part == model.torso_part);

  % Choose render color.
  if ~valid_direction
    if any(options.highlight == part)
      color = (options.invalid_color + options.highlight_color) / 2;
    else
      color = options.invalid_color;
    end
  else
    if any(options.highlight == part)
      color = options.highlight_color;
    else
      color = options.color;
    end
  end

  for k = 1:length(part_bones)
    i = edges(k, 1);
    j = edges(k, 2);
    joint = new_points(i, :)';
    bone = this.pose.bones(part_bones(k), :)';
    
    % Apply current direction to bone.
    bone(3) = (-1) ^ directions(z) * bone(3);
    % Set position of point after bone.
    new_points(j, :) = joint + bone;

    % Render this part.
    bone_bounds = render_bone(joint, bone, options.thickness, color, 1.0);
    hold on;
    bounds = combine_boxes(bounds, bone_bounds);
  end
  
  % Construct new ambiguous poses structure 
  pose = ValidatedPose(this.pose, this.directions, this.groups, this.valid);
  pose.set_direction(part, directions(z));
  
  % Find children of this part.
  child_parts = find(model.part_hierarchy == part);
  % Recurse using partial solution.
  for i = 1:length(child_parts)
    next_part = child_parts(i);
    child_bounds = render_part(pose, next_part, valid_direction, new_points, ...
      options);
    % Find bounding box of whole body.
    bounds = combine_boxes(bounds, child_bounds);
  end
end

end

classdef SkeletonModel < handle
  % Describes a model of a skeleton with a rigid torso.
  
  properties
    % The skeleton is made up of a set of joints.
    num_joints
    joint_names
    % The parent of each joint.
    joint_hierarchy
    % The name of the bone connecting a joint to its parent .
    bone_names
    % Pairs of bones which are of equal length.
    symmetric_bones

    % The skeleton is divided into several rigid parts.
    parts
    num_parts
    part_names
    % The parent of each part.
    part_hierarchy
    % Torso is required for solving structure from motion.
    torso_part
    % Head must be rendered differently to other bones.
    head_part

    %{
    % Which part does each bone belong to?
    bone_parts
    % Which bones make up each part?
    part_bones
    % Number of bones in the skeleton model (number of joints - 1).
    num_bones
    % Bones are pairs of joint indices.
    bones
    % List of sets of joints which form a rigid body.
    rigid_bodies
    
    % How are the parts grouped for doing kinematics?
    num_groups
    groups
    group_names
    group_bones
    %}
  end
  
  methods
    function this = SkeletonModel(num_joints, joint_hierarchy, joint_names, ...
        bone_names, symmetric_bones, parts, part_hierarchy, part_names, ...
        torso_part, head_part)
      
      this.num_joints = num_joints;
      this.joint_hierarchy = joint_hierarchy;
      this.joint_names = joint_names;
      this.bone_names = bone_names;
      this.symmetric_bones = symmetric_bones;

      this.parts = parts;
      this.num_parts = length(parts);
      this.part_hierarchy = part_hierarchy;
      this.part_names = part_names;
      this.head_part = head_part;
      this.torso_part = torso_part;
    end
  end
end

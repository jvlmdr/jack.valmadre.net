function edges = bone_edges(this, bones)
% Returns a length(bones) x 2 matrix of joint indices.

% Find the parent and child joints of all bones.
j = bones + 1;
i = this.joint_hierarchy(j);

edges = [i(:), j(:)];

end

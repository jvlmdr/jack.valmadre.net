function bones = part_bones(this, part)
% Finds the bone indices of all bones in a part.
%
% Parameters:
% part -- The index of the part.

% Find the parents of all joints in the part.
j = this.parts{part};
i = this.joint_hierarchy(j);

% Both the joint and its parent must be in the part.
mask = ismember(i, j);
% Extract all joints which are in the part, subtract 1 for bone index.
bones = j(mask) - 1;

end

function bounds = bounding_box(points)
% Returns a bounding box for a given set of points.
%
% Parameters:
% points -- n x d matrix of n points.

bounds = [min(points, [], 1); max(points, [], 1)];

end

function result = solution(this, group, index)

num_parts = this.kinematics(group).num_parts;
result = number_to_binary(index - 1, num_parts);

end

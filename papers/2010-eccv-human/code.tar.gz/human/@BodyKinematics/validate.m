function validated = validate(this, ambiguous_pose)

pose = ambiguous_pose.pose;
directions = ambiguous_pose.directions;

all_valid = cell(1, this.num_groups);
all_kinematics = KinematicsGroup([1, this.num_groups]);

for i = 1:this.num_groups
  % Extract information from pose for doing kinematics.
  kinematics = this.groups(i).create(pose);
  num_combinations = kinematics.num_combinations;
  % Solve inverse kinematics.
  kinematics.evaluate();

  % Copy upper and lower limits to check all combinations.
  lower = this.limits{i}(:, 1);
  upper = this.limits{i}(:, 2);
  lower = repmat(lower', [num_combinations, 1]);
  upper = repmat(upper', [num_combinations, 1]);
  % Compare angles against limits.
  angles = kinematics.angles;
  valid = and(lower <= angles, angles <= upper);
  valid = all(valid, 2);

  % Build list of kinematics and validity.
  all_kinematics(i) = kinematics;
  all_valid{i} = valid;
end

validated = ValidatedPose(pose, directions, all_kinematics, all_valid);

end

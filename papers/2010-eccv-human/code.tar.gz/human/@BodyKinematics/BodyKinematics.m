classdef BodyKinematics < handle
  % Analyses the kinematics of an ambiguous pose.
  
  properties
    groups
    num_groups
    limits
  end
  
  methods
    function this = BodyKinematics(groups, limits)
      num_groups = length(groups);

      for i = 1:num_groups
        % Number of discrete solutions within this set of groups.
        num_parts = groups(i).num_parts;
        num_solutions = 2 ^ num_parts;
      end

      this.groups = groups;
      this.num_groups = num_groups;
      this.limits = limits;
    end

    function groups = groups_containing_part(this, part)
      contains = arrayfun(@(x) any(x.parts == part), this.groups);
      groups = find(contains);
    end
  end
end

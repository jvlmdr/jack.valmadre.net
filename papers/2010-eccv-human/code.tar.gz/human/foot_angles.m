function q = foot_angles(foot)
% Parameters:
% foot -- 3x1 foot vector.

% Find the angles.
q1 = atan2(foot(1), foot(3));
q2 = atan2(-foot(2), sqrt(foot(1)^2 + foot(3)^2));
q = [q1; q2];

end

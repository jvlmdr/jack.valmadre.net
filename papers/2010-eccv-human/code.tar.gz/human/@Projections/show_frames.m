function show_frames(this, frames, varargin)
% Renders all figures in subplots.
%
% Parameters:
% varargin -- Additional arguments to show_frame().

num_frames = length(frames);

cols = ceil(sqrt(num_frames));
rows = ceil(num_frames / cols);

for i = 1:num_frames
  frame = frames(i);

  subplot(rows, cols, i);
  this.show_frame(frame, varargin{:});
  title(sprintf('Image %d', frame));
end

end

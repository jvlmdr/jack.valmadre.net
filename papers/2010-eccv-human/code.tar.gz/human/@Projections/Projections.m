classdef Projections < handle
  % Describes 2D labels of a skeleton over several frames.
  
  properties
    % Skeleton model used.
    model
    % Number of frames.
    num_frames
    % Collection of points.
    % 3D matrix: num_frames x num_joints x 2
    points
    % The images which the points were marked on.
    images
  end
  
  methods
    function this = Projections(model, points, images)
      num_frames = size(points, 1);
      
      % Check that there are as many 2D coordinates as joints.
      assert(size(points, 2) == model.num_joints, ...
        'Number of 2D coordinates does not match number of joints');
      % Check that the coordinates are two-dimensional.
      assert(size(points, 3) == 2, 'Coordinates are not 2D');
      % Check that there are the right number of images
      if nargin > 2
        assert(length(images) == num_frames, 'Wrong number of images');
      end

      % Normalize image coordinates.
      for t = 1:num_frames
        points(t, :, :) = normalize_image(images{t}, points(t, :, :));
      end

      this.model = model;
      this.num_frames = num_frames;
      this.points = points;
      this.images = images;
    end
  end
end

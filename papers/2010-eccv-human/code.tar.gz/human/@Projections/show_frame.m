function show_frame(this, frame, labels, color)
% Renders an image, optionally with its stick figure.
%
% Parameters:
% frame -- Frame number to draw.
% labels -- Whether or not to render the stick figure (optional).
% color -- Color of the stick figure (optional).

if ~exist('labels', 'var')
  labels = true;
end
if ~exist('color', 'var')
  color = [0.8, 0, 0];
end

% Graphical config.
marker = 'x';
linewidth = 2;
markersize = 8;

height = size(this.images{frame}, 1);
width = size(this.images{frame}, 2);
x = ([1, width] - 1) / max(width, height);
y = ([height, 1] - 1) / max(width, height);

image(x, y, this.images{frame});
set(gca, 'YDir', 'normal');
hold on;

if labels
  for i = 2:this.model.num_joints
    j = this.model.joint_hierarchy(i);
    u = this.points(frame, [i, j], 1);
    v = this.points(frame, [i, j], 2);

    % Draw each bone over the image.
    line(u, v, 'Color', color, 'Marker', marker, 'LineWidth', linewidth, ...
      'MarkerSize', markersize);
  end
end

hold off;
axis image;
axis off;

end

function show_all(this, varargin)
% Renders all figures in subplots.
%
% Parameters:
% varargin -- Additional arguments to show_frame().

this.show_frames(1:this.num_frames, varargin{:});

end

example = 'roethlisberger'; % Also clarke, kim-yu-na, nadal.

load(['demo/', example, '/data.mat']);
images = cell(num_images, 1);
for i = 1:num_images
  images{i} = imread(['demo/', example, '/', num2str(i), '.jpg']);
end

% Load skeleton and kinematics models.
[skeleton, kinematics] = wei_chai_model();
% Create an object which helps the user label images.
labeler = BodyLabeler(skeleton, images);

% Show the original set of photographs.
clf;
labeler.projections().show_all(false);
disp('Original photographs. (press any key)');
pause;

% Manually label images?
if input_yes_no('Manually label all images? (y/n) ')
  % Label every image.
  for i = 1:length(images)
    clf;
    labeler.label(i);
  end
  projections = labeler.projections();
else
  % Use pre-labeled points from mat file.
  disp('Here''s one I prepared earlier!');
  projections = Projections(skeleton, prelabeled, images);
end

% Show all photographs with 2D labels.
clf;
projections.show_all(true);
disp('Photographs with manual 2D labels. (press any key)');
pause;

% Solve for ambiguous poses.
disp('Solving rigid SFM for torso...');
ambiguous_poses = find_poses(projections);
clf;
% Show photo with labels.
subplot(1, 3, 1);
projections.show_frame(1, true);
title('Photograph');
% Show 3D stick figure from the front.
subplot(1, 3, 2);
ambiguous_poses(1).render();
view(0, 0);
axis off;
axis vis3d;
title('Front');
% Show 3D stick figure from the side.
subplot(1, 3, 3);
ambiguous_poses(1).render();
view(90, 0);
axis off;
axis vis3d;
title('Side');
disp('Discrete sign ambiguity remains. (press any key)');
pause;

% Solve inverse kinematics.
disp('Solving inverse kinematics for all solutions in all images...');
% arrayfun() cannot return classes :(
validated_poses = ValidatedPose(size(ambiguous_poses));
for i = 1:numel(ambiguous_poses)
  validated_poses(i) = kinematics.validate(ambiguous_poses(i));
end
% Show invalid solutions.
clf;
% Show photo with labels.
subplot(1, 2, 1);
projections.show_frame(1, true);
% Show 3D stick figure from the front.
subplot(1, 2, 2);
validated_poses(1).render();
view(45, 22.5);
axis off;
axis vis3d;
disp('Inverse kinematics identifies "invalid" solutions. (press any key)');
pause;

% Prune invalid solutions from validated poses.
% Copy all poses first.
pruned_poses = ValidatedPose(size(validated_poses));
for i = 1:numel(validated_poses)
  pruned_poses(i) = validated_poses(i).copy();
end
% Solve inverse kinematics.
disp('Pruning "invalid" solutions in all images...');
for i = 1:numel(ambiguous_poses)
  pruned_poses(i).prune_invalid();
end
% Show ambiguous vs. validated vs. pruned.
% Show original ambiguity.
subplot(1, 3, 1);
ambiguous_poses(1).render();
axis off;
axis vis3d;
title('Ambiguous');
% Show poses after validation.
subplot(1, 3, 2);
validated_poses(1).render();
axis off;
axis vis3d;
title('Validated');
% Show 3D stick figure from the side.
subplot(1, 3, 3);
pruned_poses(1).render();
axis off;
axis vis3d;
title('Pruned');
disp('The invalid solutions can be pruned. (press any key)');
pause;

% Still need to resolve ambiguity in pruned poses.
resolver = AmbiguityResolver(pruned_poses, projections);
% Does the user want to manually resolve the ambiguities?
if input_yes_no('Manually resolve depth ambiguities? (y/n) ')
  resolver.resolve();
else
  % Use pre-labeled points from mat file.
  disp('Here''s one I prepared earlier!');
  for i = 1:length(images)
    pruned_poses(i).directions = preresolved{i};
  end
end

% Extract pose from ambiguity.
final_pose = pruned_poses(1).final_pose();
clf;
% Show photo with labels.
subplot(1, 2, 1);
projections.show_frame(1, true);
% Show final pose.
subplot(1, 2, 2);
final_pose.render([0.8, 0.4, 0.2], 1);
axis off;
axis vis3d;
disp('The final pose.');


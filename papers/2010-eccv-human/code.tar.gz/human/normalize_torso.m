function R = normalize_torso(bones, torso_index)
% Finds the rotation transform such that the coordinates align with the torso.
%
% Parameters:
% bones -- 3 x N matrix of relative bone vectors.
% torso_index -- Indices of back, left clavicle and right clavicle bones.

torso_bones = bones(:, torso_index);

% Extract individual torso vectors.
back = torso_bones(:, 1);
lclavicle = torso_bones(:, 2);
rclavicle = torso_bones(:, 3);

% Ensure back is vertical, three outer points lie on i-j plane.
lshoulder = back + lclavicle;
rshoulder = back + rclavicle;
k = cross(lshoulder, rshoulder);
i = cross(back, k);
j = cross(k, i);

% Construct rotation matrix.
i = i / norm(i);
j = j / norm(j);
k = k / norm(k);

R = [i, j, k]';

end

function bounds = render_bone(d, v, t, color, a, wireframe)
% Renders a bone in 3D, returning a bounding box.
%
% Parameters:
% d -- Position of bone. 3x1.
% v -- Vector representing bone direction and length. 3x1.
% t -- Width of bone.
% color -- Color of bone.
% a -- Alpha component of bone (0 is transparent, 1 is opaque).

if nargin < 6
  wireframe = true;
end

% Number of mesh divisions.
n = 8;

height = norm(v);
% Find rotation transform to align sphere with bone.
% k is the unit vector along the bone.
k = v / norm(v);
% Find two directions perpendicular to k, given by the nullspace of k'.
X = null(k');
R = [X, k];

% Construct unit sphere.
[x, y, z] = sphere(n);
% Stretch to achieve thickness and height.
x = t * x;
y = t * y;
z = height / 2 * (z + 1);

% Rotation and offset transform.
points = [x(:), y(:), z(:)];
m = size(points, 1);
points = (R * points')' + ones(m, 1) * d';
x = reshape(points(:, 1), size(x));
y = reshape(points(:, 2), size(y));
z = reshape(points(:, 3), size(z));

h = surf(x, -z, y);

% Set colors, transparency and wireframe.
set(h, 'FaceColor', color);
alpha(h, a);
if wireframe
  set(h, 'EdgeColor', 0.5 * color);
else
  set(h, 'EdgeColor', 'none');
end

bounds = bounding_box([x(:), y(:), z(:)]);

end

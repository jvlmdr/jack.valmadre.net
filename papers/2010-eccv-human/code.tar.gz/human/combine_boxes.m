function bounds = combine_boxes(A, B)
% Combines two bounding boxes.
%
% Parameters:
% A, B -- 2 x d matrix of points.

bounds = bounding_box([A; B]);

end

classdef KinematicsGroup < handle
  % Describes a group of parts with independent inverse kinematics.
  
  properties
    % Model of this group of parts.
    model
    % Cell array of bone vectors.
    parts
    % Matrix of direction combinations to test.
    % Must contain only zeros and ones.
    combinations
    num_combinations
    % Angles of all joints.
    angles
  end
  
  methods
    function this = KinematicsGroup(model, parts)
      if nargin == 2
        assert(length(parts) == model.num_parts, ...
          'Number of parts does not match kinematics model');

        % Evaluate all combinations.
        num_combinations = 2 ^ model.num_parts;
        combinations = number_to_binary(0:num_combinations-1, model.num_parts);

        this.model = model;
        this.parts = parts;
        this.combinations = combinations;
        this.num_combinations = num_combinations;
        this.angles = nan(num_combinations, model.num_angles);
      elseif nargin == 1
        sz = model;
        this(prod(sz)) = KinematicsGroup();
        reshape(this, sz);
      elseif nargin > 0
        error('Incorrect number of arguments');
      end
    end

    function evaluate(this)
      angles = nan(this.num_combinations, this.model.num_angles);

      for i = 1:this.num_combinations
        % Copy parts and apply directions to z-component.
        parts = cell(this.model.num_parts, 1);
        for j = 1:this.model.num_parts
          direction = (-1) ^ this.combinations(i, j);
          parts{j} = this.parts{j} * diag([1, 1, direction]);
        end

        % Evaluate inverse kinematics function on part configuration.
        angles(i, :) = this.model.solve(parts);
      end

      this.angles = angles;
    end
  end
end

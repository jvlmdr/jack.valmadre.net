classdef BodyLabeler < handle
  % Describes an object to label bodies in 2D.
  
  properties
    model
    num_frames
    points
    images
  end
  
  methods
    function this = BodyLabeler(model, images)
      % Constructs an object to label images.
      % Parameters:
      % model -- SkeletonModel for labeling joints.
      % images -- Cell array of images, each of which is a 3D uint8 matrix.

      num_joints = model.num_joints;
      num_frames = length(images);

      this.model = model;
      this.num_frames = num_frames;
      this.points = nan(num_frames, num_joints, 2);
      this.images = images;
    end
    
    function projections = projections(this)
      % Gets the projections from the labeler.
      projections = Projections(this.model, this.points, this.images);
    end
  end
end

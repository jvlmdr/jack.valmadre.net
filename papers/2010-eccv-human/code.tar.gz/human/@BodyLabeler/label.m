function label(this, frame)

% Visual config.
color = [0.7, 0, 0];
line_width = 2;
marker_size = 8;
highlight_color = [0.8, 0.8, 0];

num_joints = this.model.num_joints;
joints = nan(num_joints, 2);

% Current joint.
i = 1;
finished = false;

while ~finished
  % Draw image, flip Y back to normal.
  height = size(this.images{frame}, 1);
  width = size(this.images{frame}, 2);
  hold off;
  image([1, width], [height, 1], this.images{frame});
  hold on;
  set(gca, 'YDir', 'normal');
  axis image;
  
  % Draw skeleton up to the current joint.
  % Draw bones.
  for j = 1:i-1
    % Place a marker at each joint.
    plot(joints(j, 1), joints(j, 2), 'Color', color, ...
      'LineWidth', line_width, 'Marker', 'x', 'MarkerSize', marker_size);
    if j > 1
      % Draw a line from parent joint.
      k = this.model.joint_hierarchy(j);
      points = [joints(k, :); joints(j, :)];
      line(points(:, 1), points(:, 2), 'Color', color, 'LineWidth', line_width);
    end
  end

  % Highlight parent of current joint.
  if i > 1 && i <= num_joints
    k = this.model.joint_hierarchy(i);
    plot(joints(k, 1), joints(k, 2), 'Color', highlight_color, ...
      'LineWidth', line_width, 'Marker', 'o', 'MarkerSize', marker_size);
  end
  
  if i > num_joints
    % Finished labeling, ask user to press space to confirm.
    xlabel('Space or left-click to accept, backspace or right-click to undo.');
    % Input position from user.
    button = [];
    while isempty(button)
      [x, y, button] = ginput(1);
    end

    if button == 27
      % User pressed escape. Abort.
      return;
    elseif button == 32 || button == 1
      % User pressed space or left clicked.
      finished = true;
    elseif button == 8 || button == 3
      % User pressed backspace or right click. Go back one.
      i = i - 1;
    end
  else
    % Keep labeling joints.
    xlabel('Backspace or right-click to undo, escape to abort.');

    % Tell the user which joint they're labeling.
    title(this.model.joint_names{i});

    % Input position from user.
    button = [];
    while isempty(button)
      [x, y, button] = ginput(1);
    end

    if button == 27
      % User pressed escape. Abort.
      return;
    elseif button == 8 || button == 3
      % User pressed backspace or right click. Go back one.
      i = max(i - 1, 1);
    elseif button == 1
      % User clicked left mouse. Save the joint position.
      joints(i, :) = [x; y];
      i = i + 1;
    end
  end
end

this.points(frame, :, :) = joints;

end

function Q = edge_vectors(Q, edges)

Q = Q(:, edges(:, 2)) - Q(:, edges(:, 1));

end

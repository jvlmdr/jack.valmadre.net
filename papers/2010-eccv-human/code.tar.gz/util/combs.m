function c = combs(n, k)
% Returns (n-choose-k) x k matrix where each row is a unique combination.

x = 1:k;
c = x;
i = 2;

while x(1) ~= n - k + 1
  j = k;
  x(j) = x(j) + 1;
  while x(j) > n - (k - j)
    j = j - 1;
    x(j) = x(j) + 1;
  end
  x(j+1:k) = x(j) + (1:k-j);
  c(i, :) = x;
  i = i + 1;
end

end

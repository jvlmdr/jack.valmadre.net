function y = normalize_image(img, x)
% Normalizes some points from pixel space to [0, 1]^2.

width = size(img, 2);
height = size(img, 1);
scale = 1 / max(width, height);

y = scale * (x - 1);

end

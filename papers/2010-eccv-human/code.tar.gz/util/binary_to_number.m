function x = binary_to_number(y)

[m, n] = size(y);
x = zeros(m, 1);
multiplier = 1;

for i = 1:n
  x = x + y(:, i) * multiplier;
  multiplier = multiplier * 2;
end

end

function lengths = edge_lengths(S, edges)

S_rel = edge_vectors(S, edges);
lengths = sqrt(sum((S_rel').^2, 2));

end

function x = unnormalize_image(img, y)
% Normalizes some points from pixel space to [0, 1]^2.

width = size(img, 2);
height = size(img, 1);
scale = 1 / max(width, height);

x = y / scale + 1;

end

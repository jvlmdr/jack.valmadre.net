function said_yes = input_yes_no(prompt)

valid = false;

while ~valid
  response = input(prompt, 's');
  % Case-insensitive.
  response = lower(response);
  % Remove leading/trailing spaces.
  response = strtrim(response);

  if strcmp(response, 'y') || strcmp(response, 'yes')
    valid = true;
    said_yes = true;
  elseif strcmp(response, 'n') || strcmp(response, 'no')
    valid = true;
    said_yes = false;
  end
end

end

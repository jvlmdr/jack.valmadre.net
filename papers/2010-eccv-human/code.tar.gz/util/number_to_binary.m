function y = number_to_binary(x, n)
% x -- number to convert
% n -- number of bits

m = length(x);
y = zeros(m, n);

if any(x < 0)
  error('All numbers must be non-negative');
end

for i = 1:n
  y(:, i) = mod(x, 2);
  x = floor(x / 2);
end

if any(x > 0)
  error('Number was too large for number of bits');
end

end

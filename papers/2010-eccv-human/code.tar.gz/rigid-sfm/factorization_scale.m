function s = factorization_scale(W, R, S)
% Calculates the optimal set of scales.
% W -- 2F x N matrix of projected points, relative to centroid.
% R -- 2F x 3 matrix of interleaved projection matrices.
% S -- 3 x N matrix of points, relative to centroid.

[m, n] = size(W);
F = m / 2;

% Normalize each (i, j) pair to be unit length.
v = sqrt(sum(R.^2, 2));

% W = R S = diag(v) * A
% W' = A' * diag(v)
% vec(W') = blkdiag(a_1, ..., a_m) * v = blkdiag(a_1, ..., a_m) * [I; I] * s
% vec(W') = B * s
A = diag(1 ./ v) * R * S;
rows = mat2cell(A', n, ones(m, 1));
B = blkdiag(rows{:}) * [eye(F); eye(F)];

% Find s that minimizes projection error with i and j equal magnitude.
% Note that each s_f can actually be solved alone instead of solving for
% all at once, but then you'd need a for loop.
s = B \ vec(W');

end

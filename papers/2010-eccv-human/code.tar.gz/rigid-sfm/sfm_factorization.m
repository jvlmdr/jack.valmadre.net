function [structure, scales, flag] = sfm_factorization(W)
% Solves structure from motion using Tomasi & Kanade's factorization method.
% Parameters:
% W -- 2F x N measurement matrix.
%
% Returns:
% structure -- 3D structure in each image.
% scales -- Relative camera scale in each image.

F = size(W, 1) / 2;
N = size(W, 2);

% Find centroid in each frame.
W_mean = mean(W, 2);
W_tilde = W - W_mean * ones(1, N);

% SFM factorization.
[R_hat, S_hat] = factorization_svd(W_tilde);
% Affine correction matrix.
[R, S, flag] = metric_upgrade(R_hat, S_hat);
if flag ~= 0
  % Non-zero flag means error state.
  structure = NaN;
  scales = NaN;
else
  % Find optimal scale.
  scales = factorization_scale(W_tilde, R, S);
  % Transform the structure back into the frame of each camera.
  structure = factorization_transform(R, S, scales, W_mean);
end

end

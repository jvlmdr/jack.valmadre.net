function rotations = factorization_rotations(R, scales)
% structures -- Fx3xN matrix of 3D structure in each frame.

F = size(R, 1) / 2;

% Extract i and j vectors.
I = R(1:F, :);
J = R(F + (1:F), :);

% Find each k using cross product.
K = cross(I, J, 2);
% Normalize k vectors.
K_norm = sqrt(sum(K .^ 2, 2));
K = diag(1 ./ K_norm) * K;
% Use camera scale to set the magnitude of k.
K = diag(scales) * K;

rotations = zeros(F, 3, 3);
rotations(:, 1, :) = I;
rotations(:, 2, :) = J;
rotations(:, 3, :) = K;

end

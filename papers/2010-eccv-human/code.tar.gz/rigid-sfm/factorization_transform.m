function [structures, rotations] = factorization_transform(R, S, scales, Q_mean)
% Parameters:
% R -- 2Fx3 matrix of cameras.
% S -- 3xN matrix of points, expressed relative to their centroid.
% scales -- Fx1 vector of scales.
% Q_mean -- Original centroid of S matrices.
%
% Returns:
% structures -- Fx3xN matrix of 3D structure in each frame.

F = size(R, 1) / 2;
N = size(S, 2);

% Extract rotations from projection matrices.
rotations = factorization_rotations(R, scales);

% Flatten, multiply and reshape.
R = reshape(rotations, [F * 3, 3]);
structures = R * S;
structures = reshape(structures, [F, 3, N]);

% Add offset.
offset = zeros(F, 3, N);
offset(:, 1, :) = Q_mean(1:F) * ones(1, N);
offset(:, 2, :) = Q_mean(F + (1:F)) * ones(1, N);
structures = structures + offset;

end

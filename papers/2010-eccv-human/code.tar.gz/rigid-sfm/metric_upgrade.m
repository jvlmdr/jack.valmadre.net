function [R, S, flag] = metric_upgrade(R, S)
% Convex solution to metric upgrade with semidefinite constraint.

flag = 0;

% Number of frames.
F = size(R, 1) / 2;

% Construct matrix A such that norm(A * vec(Q)) defines orthonormality error.
A = zeros(2 * F, 3, 3);
for f = 1:F
  i = R(f, :)';
  j = R(F + f, :)';

  % Orthonormality constraints.
  A(f, :, :) = i * i' - j * j';
  A(F + f, :, :) = i * j';
end
A = reshape(A, [2 * F, 3 * 3]);

% Fix scale freedom by setting ||i_1|| = 1.
i_1 = R(1, :)';
C = vec(i_1 * i_1')';
d = 1;

cvx_begin sdp quiet
  variable Q(3, 3) symmetric;
  q = vec(Q);
  
  minimize norm(A * q, 2)
  subject to
    % Q = G G', so it must be positive semidefinite.
    Q >= 0;

    % ||i_1|| == 1.
    C * q - d == 0;
cvx_end

% eig() doesn't like it when cvx spits out a sparse Q, and Q is only 3x3.
Q = full(Q);

% Hope that Q came back positive-definite!
% (negative eigenvalue => imaginary correction matrix)
[V, D] = eig(Q);
eigval = min(diag(D));
if eigval <= 0
  % At least one eigenvalue zero or negative!
  fprintf('Minimum eigval of correction matrix: %g\n', eigval);
  flag = bitor(flag, 1);
  R = NaN;
  S = NaN;
else
  G = V * sqrt(D);
  % Apply affine transformation.
  R = R * G;
  S = G \ S;
end

end

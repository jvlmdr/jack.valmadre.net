function [R, S] = factorization_svd(W)
% Performs a rank-3 factorization, W = R S.

% W is m-by-n.
[m, n] = size(W);
% U is m-by-m, V is n-by-n, sigma is m-by-n.
[U, sigma, V] = svd(W);

% If W is less than rank-3, insert zeros to obtain a factorization.
if m < 3
  % Pad columns of U with zeros.
  U = [U, zeros(m, 3-m)];
  % Pad rows of sigma with zeros.
  sigma = [sigma; zeros(1, n)];
  m = 3;
end
if n < 3
  % Pad columns of V with zeros.
  V = [V, zeros(n, 3-n)];
  % Pad columns of sigma with zeros.
  sigma = [sigma, zeros(m, 1)];
  n = 3;
end

% Enforce rank 3: extract the largest-singular-value partitions.
U = U(:, 1:3);
sigma = sigma(1:3, 1:3);
V = V(:, 1:3);
% sigma is diagonal, sigma^0.5 = sigma .^ 0.5.
% sigma is guaranteed to be real and positive.
R = U * sqrt(sigma);
S = sqrt(sigma) * V';

end
